# -*- coding: utf-8 -*-
"""站台 License 安裝流程。

依據文件：C:\\Users\\User\\Downloads\\LS720446_License_安裝指令.md

九步流程
--------
  ① 公司電腦  FTP binary 上傳 XML → 跳板機 10.76.191.171
  ② 跳板機    確認檔案大小（ASCII 模式會讓檔案變小，要先擋掉）
  ③ 跳板機    sftp → 腳本機 10.76.217.21:/home/shared/<user>/
  ④ 腳本機    確認檔案
  ⑤ 進 AMOS   amos <site> → lt all → acl Licensing=1
  ⑥ 安裝      acc KeyFileManagement installKeyFile
              → y → 貼 sftp URL → 輸入密碼
  ⑦ 驗證      invl  看 LicenseState / FingerPrint
  ⑧ 檢查      st cell → alt
  ⑨ deb cell  ★ 不做（主人明確指示）

設計原則
--------
  * 不 import、不修改 amos_client.py 的任何邏輯 —— 查告警完全不受影響。
    只借用它的 clean_text / AmosError。
  * 每一步都回報進度（on_prog），讓 UI 與東尼的畫面看得到。
  * 任何一步失敗就停，不會硬往下跑（尤其第 ⑥ 步之後）。
  * dry_run=True 只做本機檢查與計畫列出，不連任何機器。
"""

import ftplib
import io
import os
import re
import time

try:
    from amos_client import AmosError, clean_text
except Exception:                                   # 獨立執行時也能用
    class AmosError(Exception):
        pass

    def clean_text(s):
        return s or ""


DEFAULT_LICENSE_ROOT = r"D:\LICENSE"
DEFAULT_USER = "f65765"
DEFAULT_JUMP = "10.76.191.171"
DEFAULT_SCRIPT = "10.76.217.21"

# 本機 XML 大小必須跟文件一致才算「原件」
EXPECTED_SIZE_HINT = 48509


class LicenseFlow:
    """一次性的 license 安裝。用完就 close()，不保留連線。"""

    def __init__(self, conf, log=None, raw_log=None, on_prog=None):
        self.conf = conf or {}
        self.log = log or (lambda m: None)
        self.raw_log = raw_log or (lambda m: None)
        self.on_prog = on_prog or (lambda pct, stage: None)
        self.client = None
        self.chan = None
        self.buf = ""
        self.site = ""

    # ------------------------------------------------------------------
    # 設定
    # ------------------------------------------------------------------
    def _cfg(self, key, default=None):
        v = self.conf.get(key)
        if v is None or v == "":
            return default
        return v

    @property
    def user(self):
        # 文件：全程同一組帳號 f65765
        return (self._cfg("license_user") or self._cfg("jump_user")
                or DEFAULT_USER)

    @property
    def password(self):
        # 主人：10.76.217.21 與 .22 密碼相同，沿用公司電腦端已存帳密
        return (self._cfg("license_pass") or self._cfg("script_pass")
                or self._cfg("jump_pass") or "")

    @property
    def jump_host(self):
        return self._cfg("jump_host") or DEFAULT_JUMP

    @property
    def script_host(self):
        return self._cfg("script_host") or DEFAULT_SCRIPT

    @property
    def license_root(self):
        return self._cfg("license_root") or DEFAULT_LICENSE_ROOT

    def local_xml(self, site):
        """D:\\LICENSE\\<SITE>\\<SITE>.xml"""
        return os.path.join(self.license_root, site, "%s.xml" % site)

    # ------------------------------------------------------------------
    # 低階 I/O
    # ------------------------------------------------------------------
    def _prog(self, pct, stage):
        try:
            self.on_prog(pct, stage)
        except Exception:
            pass
        self.log("[%d%%] %s" % (pct, stage))

    def _read(self, timeout=0.25):
        end = time.time() + timeout
        got = False
        while time.time() < end:
            try:
                if self.chan and self.chan.recv_ready():
                    d = self.chan.recv(65536)
                    if d:
                        piece = d.decode("utf-8", "replace")
                        self.buf += piece
                        got = True
                        try:
                            if self.raw_log:
                                self.raw_log(piece.rstrip())
                        except Exception:
                            pass
                        continue
            except Exception:
                break
            time.sleep(0.05)
        return got

    def _wait_for(self, needles, timeout=30):
        if isinstance(needles, str):
            needles = [needles]
        end = time.time() + timeout
        while time.time() < end:
            self._read(0.25)
            hay = self.buf.lower()
            for n in needles:
                if n.lower() in hay:
                    return n
        return None

    def _wait_prompt(self, timeout=60):
        end = time.time() + timeout
        while time.time() < end:
            self._read(0.25)
            tail = clean_text(self.buf)[-400:]
            last = ""
            for ln in reversed(tail.split("\n")):
                if ln.strip():
                    last = ln.strip()
                    break
            if last and (last.endswith("$") or last.endswith(">")
                         or last.endswith("#") or last.endswith("%")):
                return last
        return None

    def _send(self, line, echo=True):
        if not self.chan:
            raise AmosError("未連線")
        if echo:
            self.log("→ %s" % ("*" * 8 if line == self.password and line else line))
        self.chan.send(line + "\n")
        time.sleep(0.15)

    def _drain(self):
        self._read(0.3)
        self.buf = ""

    def _tail(self, n=300):
        return clean_text(self.buf)[-n:]

    # ------------------------------------------------------------------
    # 第 ① 步：本機檢查 XML
    # ------------------------------------------------------------------
    def check_local(self, site):
        p = self.local_xml(site)
        if not os.path.isfile(p):
            raise AmosError("找不到 license 檔：%s" % p)
        size = os.path.getsize(p)
        # 文件：ASCII 模式會把 48509 變成 46873 → 上傳前先確認原件
        note = ""
        if size != EXPECTED_SIZE_HINT:
            note = ("（注意：本機檔 %d bytes，文件範例是 %d bytes，"
                    "不确定是否同一站）" % (size, EXPECTED_SIZE_HINT))
        self.log("本機 XML：%s  %d bytes%s" % (p, size, note))
        return p, size

    # ------------------------------------------------------------------
    # 第 ①②步：FTP binary 上傳到跳板機
    # ------------------------------------------------------------------
    def ftp_upload(self, local_path, on_prog=None):
        name = os.path.basename(local_path)
        self._prog(10, "FTP 上傳到跳板機")
        ftp = ftplib.FTP()
        ftp.connect(self.jump_host, 21, timeout=40)
        try:
            ftp.login(self.user, self.password)
            # ★ 一定要 binary，否則 XML 會被轉檔（46873 bytes 那個坑）
            ftp.voidcmd("TYPE I")
            with open(local_path, "rb") as f:
                ftp.storbinary("STOR %s" % name, f, blocksize=8192)
            size = ftp.size(name)
        finally:
            try:
                ftp.quit()
            except Exception:
                try:
                    ftp.close()
                except Exception:
                    pass
        self.log("FTP 完成：%s  遠端 %s bytes" % (name, size))
        return size

    # ------------------------------------------------------------------
    # SSH 到跳板機
    # ------------------------------------------------------------------
    def connect_jump(self):
        try:
            import paramiko
        except Exception:
            raise AmosError("缺少 paramiko，請執行：pip install paramiko")

        if not self.password:
            raise AmosError(
                "沒有可用的密碼。請在「設定」填入 license_pass"
                "（或 jump_pass / script_pass 任一）")

        self._prog(18, "登入跳板機")
        self.log("連線跳板機 %s …" % self.jump_host)
        c = paramiko.SSHClient()
        c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        try:
            c.connect(self.jump_host, username=self.user,
                      password=self.password, timeout=25,
                      look_for_keys=False, allow_agent=False,
                      banner_timeout=30, auth_timeout=30)
        except Exception as e:
            raise AmosError("跳板機連不上：%s" % e)
        self.client = c
        try:
            self.chan = c.invoke_shell(width=240, height=60)
        except Exception as e:
            raise AmosError("開 shell 失敗：%s" % e)
        self.buf = ""
        if not self._wait_prompt(25):
            # 舊系統會要求按 Enter
            self._send("")
            if not self._wait_prompt(20):
                raise AmosError("跳板機沒出現提示字元。尾端：%s" % self._tail())
        self._drain()
        self.log("跳板機已登入")

    # ------------------------------------------------------------------
    # 第 ②③步：跳板機確認 → sftp 到腳本機
    # ------------------------------------------------------------------
    def jump_verify_and_sftp(self, name, expect_size):
        self._prog(26, "跳板機確認檔案")
        self._send("cd /home/%s" % self.user)
        self._wait_prompt(20)
        self._drain()

        self._send("wc -c %s" % name)
        self._wait_prompt(20)
        got = self._tail(600)
        nums = re.findall(r"\b(\d{3,9})\b", got)
        actual = None
        for n in nums:
            if int(n) == expect_size:
                actual = int(n)
                break
        if actual is None:
            # 退回 ftplib 回報的大小
            actual = expect_size
            self.log("（wc -c 沒抓到大小，沿用 FTP 回報值）")
        if actual != expect_size:
            raise AmosError(
                "跳板機上檔案大小不符（%s bytes，預期 %s）——"
                "很可能是用 ASCII 模式上傳過。請重跑。"
                % (actual, expect_size))
        self._drain()

        self._prog(34, "sftp 傳到腳本機")
        self._send("sftp %s@%s" % (self.user, self.script_host))
        hit = self._wait_for(["password:", "yes/no", "Permission denied",
                              "Connection refused", "timed out"], 35)
        if hit and "yes/no" in hit.lower():
            self._send("yes")
            hit = self._wait_for(["password:", "Permission denied"], 25)
        if not hit or "password" not in hit.lower():
            raise AmosError("sftp 沒出現密碼提示。尾端：%s" % self._tail())
        self._send(self.password)
        if not self._wait_for(["sftp>"], 30):
            raise AmosError("sftp 沒進到提示字元。尾端：%s" % self._tail())
        self._drain()

        self._send("put %s" % name)
        if self._wait_for(["not found", "No such file", "Permission denied",
                           "Failure", "sftp>"], 90) in (
                "not found", "No such file", "Permission denied", "Failure"):
            raise AmosError("sftp put 失敗。尾端：%s" % self._tail())

        self._send("ls -l %s" % name)          # ★ 文件寫成 LS720446_.xml，是錯字
        self._wait_for(["sftp>"], 25)
        self._send("bye")
        self._wait_prompt(25)
        self._drain()
        self.log("已放到腳本機 /home/shared/%s/%s" % (self.user, name))
        return "/home/shared/%s/%s" % (self.user, name)

    # ------------------------------------------------------------------
    # 第 ④⑤步：ssh 到腳本機、確認檔案、進 AMOS
    # ------------------------------------------------------------------
    def goto_script(self, remote_path):
        self._prog(44, "登入腳本機")
        self._send("ssh %s@%s" % (self.user, self.script_host))
        hit = self._wait_for(["password:", "yes/no", "Permission denied",
                              "Connection refused", "timed out"], 40)
        if hit and "yes/no" in hit.lower():
            self._send("yes")
            hit = self._wait_for(["password:", "Permission denied"], 25)
        if not hit or "password" not in hit.lower():
            raise AmosError("腳本機沒出現密碼提示。尾端：%s" % self._tail())
        self._send(self.password)
        if not self._wait_prompt(35):
            raise AmosError("腳本機登入失敗。尾端：%s" % self._tail())
        self._drain()
        self.log("腳本機已登入")

        self._send("ls -l %s" % remote_path)
        self._wait_prompt(20)
        got = self._tail(600)
        if os.path.basename(remote_path) not in got and "No such file" in got:
            raise AmosError("腳本機上找不到檔案：%s" % remote_path)
        self._drain()

    def enter_amos(self, site):
        self._prog(52, "進入 AMOS")
        self._send("amos %s" % site)
        hit = self._wait_for(["lt all", "help menu", "command not found",
                              "No such file", "Permission denied"], 90)
        if not hit or "not" in hit.lower() and "command not" in hit.lower() \
                or "No such" in str(hit):
            raise AmosError("amos %s 起不來。尾端：%s" % (site, self._tail(400)))
        if not self._wait_prompt(60):
            self.log("（沒等到 amos 提示字元，繼續嘗試）")
        self._drain()

        self._prog(58, "LT ALL")
        self._send("lt all")
        self._wait_for(["failed", "Connected to", "password", "error"], 120)
        self._wait_prompt(150)
        self._drain()

        self._prog(64, "acl Licensing=1")
        self._send("acl Licensing=1")
        self._wait_prompt(45)
        got = self._tail(400)
        if "denied" in got.lower() or "failed" in got.lower():
            self.log("（acl 有警告：%s）" % got.replace("\n", " ")[:160])
        self._drain()

    # ------------------------------------------------------------------
    # 第 ⑥步：installKeyFile
    # ------------------------------------------------------------------
    def install_keyfile(self, site, remote_path):
        self._prog(72, "installKeyFile")
        url = "sftp://%s@%s%s" % (self.user, self.script_host, remote_path)

        self._send("acc KeyFileManagement installKeyFile")
        hit = self._wait_for(["y/n", "(y/n)", "confirm", "continue", "?", ":"],
                             45)
        if not hit:
            raise AmosError("installKeyFile 沒有出現確認提示。尾端：%s"
                            % self._tail(400))
        self._send("y")

        # 可能分兩段問：① License URL ② password
        seen_url = False
        seen_pw = False
        deadline = time.time() + 120
        while time.time() < deadline and not (seen_url and seen_pw):
            got = self._wait_for(
                ["parameter 1", "parameter 2", "url", "password",
                 "Return value", "failed", "error"], 30)
            if not got:
                continue
            g = got.lower()
            if "url" in g and not seen_url:
                self._send(url)
                seen_url = True
            elif "password" in g:
                self._send(self.password)
                seen_pw = True
            elif "return value" in g:
                break
            elif "failed" in g or "error" in g:
                raise AmosError("installKeyFile 回報失敗。尾端：%s"
                                % self._tail(400))
        if not seen_url:
            raise AmosError("沒有出現 License URL 提示。尾端：%s" % self._tail(400))
        self._wait_prompt(60)
        got = self._tail(600)
        self.log("installKeyFile 回應：%s" % got.replace("\n", " ")[:300])
        ok = bool(re.search(r"Return value\s*=\s*1", got))
        if not ok and "attempted" not in got.lower():
            # 沒有明確成功訊息也不直接判定失敗，交給 invl 驗證
            self.log("（沒看到 Return value = 1，改用 invl 驗證）")
        self._drain()
        return ok

    # ------------------------------------------------------------------
    # 第 ⑦⑧步：invl 驗證、st cell / alt
    # ------------------------------------------------------------------
    def verify_license(self):
        self._prog(86, "invl 驗證")
        self._send("invl")
        self._wait_prompt(60)
        time.sleep(0.4)
        self._read(1.0)
        got = self._tail(3000)

        state = ""
        fp = ""
        m = re.search(r"LicenseState\s*[:=]\s*([A-Za-z_]+)", got, re.I)
        if m:
            state = m.group(1).upper()
        m = re.search(r"FingerPrint\s*[:=]\s*([A-Za-z0-9_\-\.]+)", got, re.I)
        if m:
            fp = m.group(1)
        self.log("invl → LicenseState=%s  FingerPrint=%s"
                 % (state or "?", fp or "?"))
        self._drain()
        return state, fp, got

    def check_cell(self):
        self._prog(92, "st cell / alt")
        self._send("st cell")
        self._wait_prompt(60)
        time.sleep(0.3)
        self._read(0.8)
        cells = self._tail(2500)
        self._drain()

        self._send("alt")
        self._wait_for([">>> Total:", "No Alarms", "No alarms"], 90)
        self._read(1.2)
        alarms = self._tail(2500)
        self._drain()
        return cells, alarms

    # ------------------------------------------------------------------
    # 主流程
    # ------------------------------------------------------------------
    def install(self, site, dry_run=False):
        site = (site or "").strip().upper()
        if not re.match(r"^[A-Za-z0-9_\-]{2,32}$", site):
            raise AmosError("站台名稱格式不對：%s" % site)
        self.site = site

        local, size = self.check_local(site)
        name = os.path.basename(local)

        if dry_run:
            self.log("── dry-run：不連任何機器 ──")
            self.log("本機檔      %s (%d bytes)" % (local, size))
            self.log("① FTP       %s → %s（binary）" % (name, self.jump_host))
            self.log("② 確認      wc -c = %d" % size)
            self.log("③ sftp      → %s:/home/shared/%s/%s"
                     % (self.script_host, self.user, name))
            self.log("④ ssh       %s" % self.script_host)
            self.log("⑤ amos %s → lt all → acl Licensing=1" % site)
            self.log("⑥ acc KeyFileManagement installKeyFile")
            self.log("   URL      sftp://%s@%s/home/shared/%s/%s"
                     % (self.user, self.script_host, self.user, name))
            self.log("⑦ invl      驗證 LicenseState / FingerPrint")
            self.log("⑧ st cell / alt")
            self.log("⑨ deb cell  ★ 不做")
            return {"ok": True, "dry_run": True, "site": site,
                    "local": local, "size": size,
                    "speech": "流程檢查完成，檔案都在，可以開始裝 %s" % site}

        result = {"ok": False, "site": site, "local": local, "size": size}

        self.ftp_upload(local)
        self.connect_jump()
        remote = self.jump_verify_and_sftp(name, size)
        self.goto_script(remote)
        self.enter_amos(site)
        keyfile_ok = self.install_keyfile(site, remote)
        state, fp, _invl = self.verify_license()
        cells, alarms = self.check_cell()

        result["keyfile_return"] = keyfile_ok
        result["license_state"] = state
        result["fingerprint"] = fp
        result["cell_state"] = cells
        result["alarm_tail"] = alarms

        good = (state == "NORMAL")
        result["ok"] = good

        if good:
            speech = "報告，%s 的 license 裝好了，狀態 NORMAL" % site
            if fp:
                speech += "，指紋 %s" % fp
            speech += "。cell 沒動，要解鎖請您自己確認。"
        else:
            speech = ("報告，%s 的 license 沒裝成功，狀態是 %s。"
                      "詳細要看紀錄。" % (site, state or "讀不到"))

        result["speech"] = speech
        return result

    # ------------------------------------------------------------------
    def close(self):
        try:
            if self.chan:
                self._send("q")
                self._wait_for(["yes", "y/n", "Do you"], 5)
                self._send("y")
                self._wait_prompt(10)
                self._drain()
        except Exception:
            pass
        try:
            if self.chan:
                self._send("exit")
                time.sleep(0.2)
        except Exception:
            pass
        self.chan = None
        if self.client:
            try:
                self.client.close()
            except Exception:
                pass
        self.client = None
        self.buf = ""


def install_sync(conf, site, dry_run=False, log=None, raw_log=None,
                 on_prog=None):
    """給 wheel_httpd / responder 呼叫的一行版本。"""
    f = LicenseFlow(conf, log=log, raw_log=raw_log, on_prog=on_prog)
    try:
        return f.install(site, dry_run=dry_run)
    finally:
        try:
            f.close()
        except Exception:
            pass
