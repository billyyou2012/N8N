# -*- coding: utf-8 -*-
"""
wheel_httpd.py — 公司電腦的「直接查詢」HTTP 服務（第二條路由）
珠珢 / 2026-10-29 15:25

★ 為什麼需要這個（主人 15:19）
     「因為你會跟東尼都在同一網路（公司），我會把 jarvis 帶回家，
      所以當 JARVIS 與東尼不同網路時，可以有第二條路由：
      你（伺服端）直接和東尼通訊去做指令查詢動作」

     原本只有一條路：
         Jarvis ──ESP-NOW──→ 東尼 ──USB──→ 公司電腦 ──→ AMOS
     Jarvis 一帶回家，ESP-NOW 斷了，整條路就死。

     這支補上第二條：
         bridge（公司筆電）──HTTP/LAN──→ 公司電腦 ──→ AMOS
     完全不經過 Jarvis，也不經過東尼。

★ 設計
     · 只做三件事：/ping（還活著嗎）、/info（狀態）、/check?site=（查詢）
     · 單一任務：正在查就回 409，不排隊（避免兩個人同時打 AMOS）
     · 綁 0.0.0.0，讓同網段的 bridge 連得到
     · 一律用執行緒跑，不擋 tkinter 主迴圈
     · 任何例外都吃掉回 JSON，不能讓整個程式掛掉

★ 安全性（務實版）
     · 預設只允許「同網段」來源（10./172./192.168.）
     · 有設 token 就要求 ?token= 相符；沒設就只靠網段
     · 不做 TLS —— 這是公司內網，且資料是告警清單，不是帳密

★ 與第一條路由的關係
     東尼走 USB 進來時，仍然照舊用 Responder。
     這支只是多開一個入口，兩者共用「正在查詢」這個狀態，
     所以不會同時對同一台 AMOS 打兩次。
"""
import ipaddress
import json
import os
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

DEFAULT_PORT = 8788

# 只允許內網來源
_ALLOW_NETS = [
    ipaddress.ip_network("10.0.0.0/8"),
    ipaddress.ip_network("172.16.0.0/12"),
    ipaddress.ip_network("192.168.0.0/16"),
    ipaddress.ip_network("127.0.0.0/8"),
]


def _ip_ok(ip):
    try:
        a = ipaddress.ip_address(ip)
    except Exception:
        return False
    return any(a in n for n in _ALLOW_NETS)


def run_check_sync(conf, site, do_lt=True, raw_log=None, on_prog=None):
    """同步跑一次 AMOS 查詢，回傳 parsed dict。失敗丟例外。"""
    import amos_client as A
    cl = A.AmosClient(conf, log=lambda m: None, raw_log=raw_log or (lambda m: None))
    try:
        if on_prog:
            on_prog(5, "連線跳板機")
        cl.connect()
        if on_prog:
            on_prog(30, "AMOS 查詢")
        parsed = cl.read_alarms(site, do_lt=do_lt)
        if on_prog:
            on_prog(95, "整理結果")
        return parsed
    finally:
        try:
            cl.quit_amos()
        except Exception:
            pass
        try:
            cl.close()
        except Exception:
            pass


class _Handler(BaseHTTPRequestHandler):
    server_version = "WheelExec/1.0"
    protocol_version = "HTTP/1.1"

    # ---- 小工具 ----
    def _j(self, code, obj):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt, *args):
        # 不要讓 http.server 的預設格式洗版面
        return

    def _deny_reason(self):
        ip = self.client_address[0]
        if not _ip_ok(ip):
            return "來源不在內網：%s" % ip
        want = self.server.token
        if want:
            qs = parse_qs(urlparse(self.path).query)
            got = (qs.get("token", [""])[0] or "").strip()
            if got != want:
                return "token 不符"
        return None

    # ---- 路由 ----
    def do_GET(self):
        u = urlparse(self.path)
        path = u.path

        why = self._deny_reason()
        if why:
            self._j(403, {"ok": False, "error": why})
            return

        if path == "/ping":
            self._j(200, {"ok": True, "role": "wheel-exec",
                          "busy": bool(self.server.is_busy()),
                          "time": time.strftime("%Y-%m-%d %H:%M:%S")})
            return

        if path == "/info":
            self._j(200, {"ok": True, "info": self.server.info()})
            return

        if path == "/cancel":
            self._j(200, {"ok": True, "cancelled": self.server.cancel()})
            return

        if path == "/check":
            qs = parse_qs(u.query)
            site = (qs.get("site", [""])[0] or "").strip().upper()
            nolt = (qs.get("nolt", ["0"])[0] or "0") == "1"
            want_raw = (qs.get("raw", ["1"])[0] or "1") != "0"
            if not site:
                self._j(400, {"ok": False, "error": "缺少 site 參數"})
                return

            # 單一任務：正在查就拒絕，不排隊
            if not self.server.acquire():
                self._j(409, {"ok": False, "error": "忙碌中",
                              "site": self.server.current_site()})
                return

            self.server.set_site(site)
            t0 = time.time()
            try:
                parsed = self.server.do_check(site, not nolt)
                ms = int((time.time() - t0) * 1000)
                raw = parsed.get("raw") or ""
                out = {
                    "ok": True,
                    "site": site,
                    "ms": ms,
                    "total": parsed.get("total", 0),
                    "critical": parsed.get("critical", 0),
                    "major": parsed.get("major", 0),
                    "minor": parsed.get("minor", 0),
                    "raw_len": len(raw),
                }
                # ★ 2026-10-29 15:28：bridge 要能做完整分析，所以把原始輸出帶回去。
                #   同網段內傳 64KB 沒問題；超過就截斷並註明。
                if want_raw:
                    out["raw"] = raw[:65536]
                    out["raw_truncated"] = len(raw) > 65536
                self._j(200, out)
            except Exception as e:
                self._j(500, {"ok": False, "site": site,
                              "error": str(e)[:200]})
            finally:
                self.server.release()
                self.server.set_site("")
            return

        self._j(404, {"ok": False, "error": "unknown path", "path": path})


class ExecHttpd:
    """薄薄一層：把 HTTP server 包起來，方便 UI 用一行啟動。"""

    def __init__(self, conf, responder=None, port=None, token="", log=None):
        self.conf = conf or {}
        self.responder = responder          # 可共用 Responder 的 busy 狀態
        self.token = token or ""
        self.log = log or (lambda m: print(m))
        self.port = int(port or self.conf.get("exec_port") or DEFAULT_PORT)
        self.httpd = None
        self._th = None
        self._busy = False
        self._site = ""
        self._lock = threading.Lock()

    # ---- 對外狀態（給 /check 用）----
    def is_busy(self):
        if self.responder is not None and getattr(self.responder, "busy", False):
            return True
        return self._busy

    def current_site(self):
        if self.responder is not None and getattr(self.responder, "busy", False):
            return getattr(self.responder, "site", "")
        return self._site

    def acquire(self):
        with self._lock:
            if self.is_busy():
                return False
            self._busy = True
            return True

    def release(self):
        with self._lock:
            self._busy = False

    def set_site(self, s):
        self._site = s or ""

    def info(self):
        d = {"port": self.port, "busy": self.is_busy(),
             "site": self.current_site(),
             "token": bool(self.token)}
        if self.responder is not None and hasattr(self.responder, "info"):
            try:
                d["responder"] = self.responder.info()
            except Exception:
                pass
        return d

    def do_check(self, site, do_lt=True):
        if self.responder is not None and hasattr(self.responder, "_run"):
            # 走 Responder 的 _run，行為跟 USB 進來的查詢完全一致
            return self.responder._run_sync(site, do_lt)
        return run_check_sync(self.conf, site, do_lt)

    def cancel(self):
        if self.responder is not None and hasattr(self.responder, "cancel"):
            try:
                return self.responder.cancel()
            except Exception:
                pass
        return False

    # ---- 啟動 ----
    def start(self):
        try:
            self.httpd = ThreadingHTTPServer(("0.0.0.0", self.port), _Handler)
            self.httpd.daemon_threads = True
            self.httpd.token = self.token
            self.httpd.is_busy = self.is_busy
            self.httpd.current_site = self.current_site
            self.httpd.acquire = self.acquire
            self.httpd.release = self.release
            self.httpd.set_site = self.set_site
            self.httpd.info = self.info
            self.httpd.do_check = self.do_check
            self.httpd.cancel = self.cancel
            self._th = threading.Thread(target=self.httpd.serve_forever,
                                        daemon=True, name="exec-httpd")
            self._th.start()
            self.log("直接查詢埠已開：http://0.0.0.0:%d/check?site=<站>" % self.port)
            return True
        except Exception as e:
            self.log("直接查詢埠開不起來（%r）；主程式照常運作" % (e,))
            return False


def register_to_bridge(bridge_url, port, log=None):
    """把自己（公司電腦）的位址告訴 bridge，讓它知道第二條路由要打哪裡。"""
    import socket
    import urllib.request
    log = log or (lambda m: None)
    if not bridge_url:
        return False
    try:
        # 用「連出去」的方式取得本機在公司網段的 IP（不會真的送出資料）
        u = urlparse(bridge_url)
        host = u.hostname
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.connect((host or "8.8.8.8", u.port or 80))
            ip = s.getsockname()[0]
        finally:
            s.close()
        url = "%s/wheel_register?ip=%s&port=%d" % (
            bridge_url.rstrip("/"), ip, int(port))
        with urllib.request.urlopen(url, timeout=8) as r:
            log("已向 bridge 登記直接查詢位址 %s:%d → HTTP %d"
                % (ip, port, r.status))
        return True
    except Exception as e:
        log("向 bridge 登記失敗（不影響本機運作）：%r" % (e,))
        return False
