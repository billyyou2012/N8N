# -*- coding: utf-8 -*-
"""
amos_client.py — 連進 Ericsson AMOS 讀基地台告警
珠珢 / 2026-10-28

連線鏈（依主人提供的實際流程）
------------------------------
  公司電腦
    └─ SSH → 跳板機 10.76.191.171（SunOS）
         └─ ssh → 腳本機 10.76.217.22（svc-2-scripting）
              └─ amos <機站名>
                   ├─ LT ALL   （登入節點，載入 MO）
                   └─ ALT      （列出告警）

★ 機站名稱會變 → 由呼叫端傳入，不寫死。

設計重點
--------
· 用 paramiko 的 PTY（invoke_shell）而不是 exec_command，
  因為 amos 是互動式 shell，exec 拿不到完整輸出。
· PTY 寬度設 240，避免長行被折行導致解析失敗。
· 解析函式 parse_alarms() 是純函式，可單獨測試，不依賴網路。
· 敏感資訊（密碼）只存在本機 config.json，不寫進程式碼。
"""
import re
import threading
import time

# ★ 2026-10-28 17:58：舊機器（SunOS 跳板機）SSH 相容設定
#   現場錯誤：Incompatible ssh peer (no acceptable kex algorithm)
#   公司跳板機只會 group1-sha1 / group14-sha1 / ssh-rsa 這些老演算法，
#   而 paramiko 5.x 已經全部移除 → 握手直接失敗。
#   這裡把新舊演算法一起列出來，新的排前面，舊的當備援。
_LEGACY_KEX = (
    # 新的優先
    "curve25519-sha256@libssh.org",
    "curve25519-sha256",
    "ecdh-sha2-nistp256",
    "ecdh-sha2-nistp384",
    "ecdh-sha2-nistp521",
    "diffie-hellman-group16-sha512",
    "diffie-hellman-group-exchange-sha256",
    "diffie-hellman-group14-sha256",
    # ↓ 舊機器需要
    "diffie-hellman-group-exchange-sha1",
    "diffie-hellman-group14-sha1",
    "diffie-hellman-group1-sha1",
)

_LEGACY_KEYS = (
    "ssh-ed25519",
    "ecdsa-sha2-nistp256",
    "ecdsa-sha2-nistp384",
    "ecdsa-sha2-nistp521",
    "rsa-sha2-512",
    "rsa-sha2-256",
    "ssh-rsa",      # ← 舊機器
    "ssh-dss",      # ← 更舊的機器
)

_LEGACY_CIPHERS = (
    "aes128-ctr", "aes192-ctr", "aes256-ctr",
    "aes128-cbc", "aes192-cbc", "aes256-cbc",   # ← 舊機器常用
    "3des-cbc",
)

_LEGACY_MACS = (
    "hmac-sha2-256", "hmac-sha2-512", "hmac-sha1",
)


def _apply_legacy_ssh(transport):
    """把舊演算法塞進一個已建立的 Transport（paramiko 2.x API）"""
    try:
        opts = transport.get_security_options()
        opts.kex = _LEGACY_KEX
        opts.key_types = _LEGACY_KEYS
        opts.ciphers = _LEGACY_CIPHERS
        opts.digests = _LEGACY_MACS
        return True
    except Exception:
        return False

# ------------------------------------------------------------
#  ANSI / 控制字元清理
# ------------------------------------------------------------
_ANSI = re.compile(
    r"\x1b\[[0-9;?]*[a-zA-Z]"                    # CSI
    r"|\x1b\][^\x07\x1b\n]*(?:\x07|\x1b\\)"      # OSC（含標題列）
    r"|\x1b\][^\n]*"                             # OSC 未終止 → 吃到行尾
    r"|\x1b[()][A-B0-9]"                         # 字元集
    r"|\x1b[=>NOP]"                              # 其他單字元序列
)

# ★ 2026-10-28 實測：主人貼的 AMOS 輸出裡「^H」是真的兩個字元（^ 與 H），
#   不是退位字元 \b。像 "^H^H^H^HUsing paramfile …"
#   不清掉會混進告警解析，也會讓畫面看起來很亂。
_CARET_H = re.compile(r"\^H+")


def clean_text(s):
    """去掉 ANSI escape、退格、以及終端機的 ^H 控制"""
    if not s:
        return ""
    s = _ANSI.sub("", s)
    s = _CARET_H.sub("", s)          # ★ 清掉字面的 ^H
    # 處理退格：字元 + \b 互相抵銷
    out = []
    for ch in s:
        if ch == "\b":
            if out:
                out.pop()
        elif ch == "\x00":
            continue
        else:
            out.append(ch)
    s = "".join(out)
    s = s.replace("\r\n", "\n").replace("\r", "\n")
    return s


# ------------------------------------------------------------
#  告警解析（純函式，可單獨測試）
# ------------------------------------------------------------
# 例：2026-10-28 06:45:49 m External Link to GNodeB Failure     ENodeBFunction=1 (X2 link ...)
#
# ★ 2026-10-28 修正（實測抓到）：
#   原本要求「問題」與「MO」之間至少 2 個空白（\s{2,}）。
#   但實際 AMOS 輸出有時只隔 1 個空白：
#     2026-10-28 07:00:00 w Cell Unavailable              ENodeBFunction=1
#     2026-10-28 06:50:00 C Loss of Service               ENodeBFunction=1
#   常見情況是表格某欄特別長時，欄寬對齊剛好只剩一個空白。
#   → 那天就會整列漏掉（實測 3 筆只抓到 1 筆）。
#
#   改法：時間 + 單一字母嚴重度 + 其餘全部，
#         「問題 vs MO」的分界改由後面處理：找最像 MO 的那一段。
_ALARM_RE = re.compile(
    r"^(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2})\s+(\S)\s+(\S.*)$"
)

# MO 一定是 "Something=數字" 或 "A=1,B=2" 這種 MO 路徑格式
_MO_SPLIT = re.compile(r"\s+(?=(?:[A-Za-z][A-Za-z0-9_]*=))")

_TOTAL_RE = re.compile(
    r">>>\s*Total:\s*(\d+)\s*Alarms?\s*\((\d+)\s*Critical,\s*(\d+)\s*Major\)",
    re.I,
)

_NOALARM_RE = re.compile(r">>>\s*(?:No\s+Alarms?|total:\s*0)", re.I)

SEV_ZH = {
    "c": "嚴重", "C": "嚴重",
    "M": "重要", "m": "次要",
    "W": "警告", "w": "警告",
}

SEV_ORDER = {"嚴重": 0, "重要": 1, "次要": 2, "警告": 3}


def parse_alarms(raw):
    """從 AMOS ALT 的原始輸出解析告警

    回傳 dict:
      {
        "alarms": [ {time, sev_raw, sev, problem, mo, extra}, ... ],
        "total": int, "critical": int, "major": int,
        "has_summary": bool,
      }
    """
    txt = clean_text(raw)
    res = {"alarms": [], "total": 0, "critical": 0, "major": 0,
           "has_summary": False}

    for line in txt.split("\n"):
        line = line.rstrip()
        if not line:
            continue
        m = _ALARM_RE.match(line)
        if not m:
            continue
        t, sev_raw = m.group(1), m.group(2)
        body = m.group(3).strip()

        # 排除表頭那一行
        if "Specific Problem" in line or "Date & Time" in line:
            continue

        # 切開「問題描述」與「MO」：MO 從第一個 Xxx= 開始
        parts = _MO_SPLIT.split(body, 1)
        problem = parts[0].strip()
        mo = parts[1].strip() if len(parts) > 1 else ""

        if not problem:
            continue

        # MO 欄位常是 "ENodeBFunction=1 (說明)" → 拆開
        extra = ""
        mm = re.match(r"^(.*?)\s*\((.+)\)\s*$", mo)
        if mm:
            mo = mm.group(1).strip()
            extra = mm.group(2).strip()

        res["alarms"].append({
            "time": t,
            "sev_raw": sev_raw,
            "sev": SEV_ZH.get(sev_raw, sev_raw),
            "problem": problem,
            "mo": mo,
            "extra": extra,
        })

    m = _TOTAL_RE.search(txt)
    if m:
        res["has_summary"] = True
        res["total"] = int(m.group(1))
        res["critical"] = int(m.group(2))
        res["major"] = int(m.group(3))
    else:
        # 沒有摘要列 → 用實際解析到的數量
        res["total"] = len(res["alarms"])
        if _NOALARM_RE.search(txt):
            res["has_summary"] = True

    # 排序：嚴重的排前面
    res["alarms"].sort(key=lambda a: SEV_ORDER.get(a["sev"], 9))
    return res


def build_speech(site, parsed, max_bytes=200):
    """把告警結果濃縮成一句給 Jarvis 唸的話（受 ESP-NOW 200 bytes 限制）"""
    alarms = parsed.get("alarms") or []
    total = parsed.get("total", len(alarms))
    crit = parsed.get("critical", 0)
    major = parsed.get("major", 0)

    if total == 0:
        core = "報告，%s 目前沒有告警" % site
    else:
        head = "報告，%s 有 %d 個告警" % (site, total)
        bits = []
        if crit:
            bits.append("%d 個嚴重" % crit)
        if major:
            bits.append("%d 個重要" % major)
        if bits:
            head += "，" + "、".join(bits)

        if alarms:
            first = alarms[0]["problem"]
            # 告警名稱是英文，保留原文比較好認
            head += "。最嚴重的是 " + first
        core = head

    # 保險：超過上限就砍尾巴（加省略號）
    b = core.encode("utf-8")
    if len(b) <= max_bytes:
        return core
    cut = core
    while len(cut.encode("utf-8")) > max_bytes - 3:
        cut = cut[:-1]
        if not cut:
            break
    return cut + "…"


# ------------------------------------------------------------
#  AMOS 連線
# ------------------------------------------------------------
class AmosError(Exception):
    pass


class AmosClient:
    """SSH 跳板 → 腳本機 → amos <site> → LT ALL → ALT"""

    def __init__(self, cfg, log=None, raw_log=None):
        self.cfg = cfg or {}
        self.log = log or (lambda m: None)
        # ★ 2026-10-29 15:12：原始終端機輸出的逐行回呼（選用）
        #   主人要看到 AMOS 每一行，不要只有階段訊息。
        self.raw_log = raw_log or (lambda m: None)
        self._raw_prev = None
        self._raw_win = 0.0
        self._raw_cnt = 0
        self.client = None
        self.chan = None
        self.buf = ""
        self.site = ""
        self._lock = threading.Lock()

    # ---------- 低階 ----------
    def _cfg(self, k, default=None):
        return self.cfg.get(k, default)

    # ★ 2026-10-29 15:12：原始輸出逐行轉發
    #   為什麼要限速：AMOS 打 LT ALL 時會一次噴幾百行，
    #   全部塞進 tkinter 會讓視窗卡住。每秒 40 行足夠看清楚，
    #   超出的直接丟（畫面是給人看的，不是要完整備份）。
    _RAW_MAX_PER_SEC = 40

    def _raw_emit(self, piece):
        """從剛收到的片段抽出完整行 → raw_log。會自己濾重複與限速。"""
        if not piece or "\n" not in piece:
            return
        head, _sep, tail = piece.rpartition("\n")
        # tail 是還沒換行的殘段 → 不放進 self._raw_part（那是給人看的，
        # 這裡刻意不留狀態，避免和 self.buf 糾纏）
        now = time.time()
        if now - self._raw_win >= 1.0:
            self._raw_win = now
            self._raw_cnt = 0
        for raw in head.split("\n"):
            s = raw.rstrip()
            if not s.strip():
                continue
            if s == self._raw_prev:      # 游標重繪常吐同樣一行
                continue
            self._raw_prev = s
            self._raw_cnt += 1
            if self._raw_cnt > self._RAW_MAX_PER_SEC:
                continue
            try:
                self.raw_log(s)
            except Exception:
                pass

    def _read_into_buf(self, timeout=0.2):
        end = time.time() + timeout
        got = False
        while time.time() < end:
            try:
                if self.chan and self.chan.recv_ready():
                    d = self.chan.recv(65536)
                    if d:
                        piece = d.decode("utf-8", "replace")
                        self.buf += piece
                        got = True
                        # ★ 2026-10-29 15:12：把「完整行」複製一份給畫面
                        #   只吐有換行的完整行，半行留著等下一批；
                        #   self.buf 本身行為完全不變，解析結果不受影響。
                        try:
                            self._raw_emit(piece)
                        except Exception:
                            pass
                        continue
            except Exception:
                break
            time.sleep(0.05)
        return got

    def _wait_for(self, needles, timeout=30, casefold=True):
        """等到 buffer 出現任一 needle；回傳命中的 needle 或 None"""
        if isinstance(needles, str):
            needles = [needles]
        end = time.time() + timeout
        while time.time() < end:
            self._read_into_buf(0.25)
            hay = self.buf.lower() if casefold else self.buf
            for n in needles:
                probe = n.lower() if casefold else n
                if probe in hay:
                    return n
        return None

    def _wait_prompt(self, timeout=60):
        """等到 shell / amos 提示字元（看 buffer 尾端）"""
        end = time.time() + timeout
        while time.time() < end:
            self._read_into_buf(0.25)
            tail = clean_text(self.buf)[-300:]
            # 尾端最後一行像 "xxx$" / "xxx>" / "[user@host ~]$"
            last = ""
            for ln in reversed(tail.split("\n")):
                if ln.strip():
                    last = ln.strip()
                    break
            if last and (last.endswith("$") or last.endswith(">")
                         or last.endswith("#")):
                return last
        return None

    def _send(self, line):
        if not self.chan:
            raise AmosError("未連線")
        self.log("→ %s" % line)
        self.chan.send(line + "\n")
        time.sleep(0.15)

    def _drain(self):
        """把目前殘留輸出收乾淨"""
        self._read_into_buf(0.3)
        self.buf = ""

    # ---------- 連線 ----------
    def connect(self):
        try:
            import paramiko
        except Exception:
            raise AmosError("缺少 paramiko，請執行：pip install paramiko")

        jh = self._cfg("jump_host")
        ju = self._cfg("jump_user")
        jp = self._cfg("jump_pass")
        sh = self._cfg("script_host")
        su = self._cfg("script_user")
        sp = self._cfg("script_pass")

        if not all([jh, ju, jp, sh, su, sp]):
            raise AmosError("AMOS 連線設定不完整（請在設定裡填跳板機與腳本機）")

        self.log("連線跳板機 %s …" % jh)
        c = paramiko.SSHClient()
        c.set_missing_host_key_policy(paramiko.AutoAddPolicy())

        # ★ 2026-10-28 18:02：舊 SunOS 跳板機相容
        #   exe 內建 paramiko 2.12.0，其「預設」KEX 就含
        #   group1-sha1 / group14-sha1 / ssh-rsa，因此直接連即可。
        #   （paramiko 5.x 移除這些演算法 → 才會出現 no acceptable kex）
        try:
            c.connect(jh, username=ju, password=jp, timeout=25,
                      look_for_keys=False, allow_agent=False,
                      banner_timeout=30, auth_timeout=30)
        except paramiko.ssh_exception.IncompatiblePeer as e:
            raise AmosError(
                "跳板機 SSH 演算法不相容（%s）。\n"
                "  這台跳板機太舊，只支援 diffie-hellman-group1-sha1 等舊演算法。\n"
                "  請確認執行端 exe 是 v2.5 之後（內建 paramiko 2.12）。" % e)
        except paramiko.ssh_exception.AuthenticationException as e:
            raise AmosError(
                "跳板機帳號或密碼錯誤（%s）。請在「設定」重新輸入。" % e)
        except Exception as e:
            raise AmosError("跳板機連不上：%s" % e)

        self.client = c
        try:
            ch = c.invoke_shell(width=240, height=60)
        except Exception as e:
            raise AmosError("開 shell 失敗：%s" % e)
        self.chan = ch
        self.buf = ""

        self.log("跳板機已登入")
        if not self._wait_prompt(20):
            raise AmosError("跳板機沒有出現提示字元（登入可能失敗）")
        self._drain()

        # ---- 第二段：ssh 到腳本機 ----
        self.log("從跳板機連腳本機 %s …" % sh)
        self._send("ssh %s@%s" % (su, sh))

        hit = self._wait_for(["password:", "yes/no", "Permission denied",
                              "Connection refused", "timed out"], 35)
        if hit and "yes/no" in hit.lower():
            self._send("yes")
            hit = self._wait_for(["password:", "Permission denied"], 25)
        if not hit or "password" not in hit.lower():
            snippet = clean_text(self.buf)[-300:]
            raise AmosError("腳本機沒出現密碼提示。畫面尾端：%s" % snippet)

        self._send(sp)
        if not self._wait_prompt(35):
            snippet = clean_text(self.buf)[-300:]
            raise AmosError("腳本機登入失敗（密碼錯誤或家目錄異常）。畫面尾端：%s" % snippet)

        self.log("腳本機已登入")
        self._drain()
        return True

    # ---------- 讀告警 ----------
    def read_alarms(self, site, do_lt=True, timeout=180):
        """讀指定機站的告警。site 例：LS722122"""
        site = (site or "").strip()
        if not site:
            raise AmosError("沒有指定機站名稱")
        if not re.match(r"^[A-Za-z0-9_\-]{2,32}$", site):
            raise AmosError("機站名稱格式不對（只接受英數、_ 與 -）：%s" % site)

        if not self.chan:
            self.connect()

        self.site = site
        self._drain()

        # ---- 進 amos ----
        self.log("進入 AMOS：amos %s" % site)
        self._send("amos %s" % site)

        hit = self._wait_for(["alt", "help menu", "command not found",
                              "No such file", "Permission denied"], 90)
        if not hit or "not" in hit.lower() or "No such" in hit:
            snippet = clean_text(self.buf)[-400:]
            raise AmosError("amos %s 起不來。畫面尾端：%s" % (site, snippet))

        # 等 amos 提示字元（<SITE>>）
        if not self._wait_prompt(60):
            self.log("（沒等到 amos 提示字元，繼續嘗試）")
        self._drain()

        # ---- LT ALL ----
        if do_lt:
            self.log("LT ALL …")
            self._send("LT ALL")
            hit2 = self._wait_for(["failed", "Connected to", "password",
                                   "error"], 120)
            if hit2 and "failed" in hit2.lower():
                snippet = clean_text(self.buf)[-400:]
                self.log("LT ALL 有問題：%s" % snippet[:200])
            # 等提示字元回來
            self._wait_prompt(120)
            self._drain()

        # ---- ALT ----
        self.log("ALT（讀告警）…")
        self._send("ALT")
        # 等摘要列或提示字元
        self._wait_for([">>> Total:", "No Alarms", "No alarms"], 90)
        # 再多收一點，確保表格最後一列完整
        self._read_into_buf(1.2)

        raw = clean_text(self.buf)
        parsed = parse_alarms(raw)
        parsed["raw"] = raw
        self.log("讀到 %d 個告警" % parsed["total"])
        return parsed

    # ---------- 收尾 ----------
    def quit_amos(self):
        """離開 amos（回腳本機 shell）"""
        if not self.chan:
            return
        try:
            self._drain()
            self._send("q")
            hit = self._wait_for(["yes", "y/n", "Do you"], 6)
            if hit:
                self._send("y")
            self._wait_prompt(15)
            self._drain()
        except Exception:
            pass

    def close(self):
        self.chan = None
        if self.client:
            try:
                self.client.close()
            except Exception:
                pass
        self.client = None
        self.buf = ""

    # ---------- 測試連線（不進 amos）----------
    def test(self):
        self.connect()
        ok = self.chan is not None
        self.close()
        return ok
