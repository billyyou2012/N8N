@echo off
chcp 65001 >nul
title 東尼控制台
cd /d "%~dp0"

echo ============================================
echo   東尼控制台
echo ============================================
echo.

where python >nul 2>nul
if errorlevel 1 (
    echo [錯誤] 找不到 python
    echo.
    echo 請先安裝 Python 3.9 以上：https://www.python.org/downloads/
    echo 安裝時務必勾選 "Add python.exe to PATH"
    echo.
    pause
    exit /b 1
)

python -c "import tkinter" >nul 2>nul
if errorlevel 1 (
    echo [錯誤] 這個 Python 沒有 tkinter（常見於 Microsoft Store 精簡版）
    echo 請改裝官方完整版 Python。
    echo.
    pause
    exit /b 1
)

echo [檢查] 必要套件...
python -c "import serial" >nul 2>nul
if errorlevel 1 (
    echo   - 安裝 pyserial ...
    python -m pip install pyserial
)

python -c "import paramiko" >nul 2>nul
if errorlevel 1 (
    echo   - 安裝 paramiko（AMOS 連線要用）...
    python -m pip install paramiko
    if errorlevel 1 (
        echo.
        echo [錯誤] paramiko 安裝失敗。請手動執行：
        echo     python -m pip install paramiko
        pause
        exit /b 1
    )
)

echo   - 套件齊全
echo.
echo 啟動中...
echo.

python little_wheel_ui.py
if errorlevel 1 (
    echo.
    echo 程式結束時發生錯誤，按任意鍵關閉...
    pause
)
