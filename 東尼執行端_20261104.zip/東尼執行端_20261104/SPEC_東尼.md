# 東尼 — 系統規格與協定

珠珢 / 2026-10-28

本文是東尼**韌體要照著實作**的規格。改動前請先看完整份。

---

## 一、角色

```
        ①喊 Jarvis
主人 ──────────────→ Jarvis（M5Stack CoreS3，客廳）
                        │
                        │ ②ESP-NOW  ← 「CHECK LS722122」
                        ▼
                     東尼（ESP32-D0WD，公司電腦旁）
                        │
                        │ ③USB 序列  ← 「CHECK LS722122」
                        ▼
                     公司電腦（Windows）
                        │
                        │ ④跑 AMOS：兩段 SSH → LT ALL → ALT
                        │ ⑤LOG 經 USB 回東尼
                        ▼
                     東尼
                        │
                        │ ⑥ESP-NOW  ← LOG 分塊
                        ▼
                     Jarvis
                        │
                        │ ⑦POST /wheel_log → 分析
                        ▼
                     用喇叭唸出
```

**東尼是純轉運站 + 兩邊橋接**，不做分析、不存資料。

---

## 二、硬體

| 項目 | 值 |
|---|---|
| 晶片 | ESP32-D0WD-V3 rev3.0（雙核 240MHz） |
| Flash | 4 MB |
| MAC | `3C:E9:0E:88:20:C0` |
| 序列埠 | COM4（CP210x USB-UART） |
| Jarvis MAC | `24:58:7C:E9:48:D4` |

---

## 三、ESP-NOW 側（對 Jarvis）

### 封包格式

```c
#define JV_MAGIC     0x4A56524Bu   // 'JVRS'

typedef struct {
    uint32_t magic;              // 必須等於 JV_MAGIC，否則丟棄
    uint8_t  type;               // 見下表
    uint8_t  seq;                // 序號（除錯用）
    uint16_t len;                // text 實際長度（不含結尾 0）
    char     text[200];          // UTF-8，含結尾 0
} __attribute__((packed)) jv_msg_t;   // 共 208 bytes
```

**ESP-NOW 單包上限 250 bytes**，此結構 208 bytes 安全。
超過必需分片（LOG 已設計成分片）。

### 訊息類型

| 值 | 名稱 | 方向 | text 內容 |
|---|---|---|---|
| 1 | `SPEAK` | 東尼 → Jarvis | 要 Jarvis 唸的話（本流程未使用） |
| 2 | `PING` | 雙向 | 空 |
| 3 | `ACK` | 雙向 | 空 |
| **4** | **`CMD`** | **Jarvis → 東尼** | `CHECK LS722122` |
| **5** | **`LOG_B`** | **東尼 → Jarvis** | `<site> <總塊數>` |
| **6** | **`LOG_D`** | **東尼 → Jarvis** | `<序號> <base64片段>` |
| **7** | **`LOG_E`** | **東尼 → Jarvis** | `<site> <原始字元數>` |

### LOG 分塊規則

```
LOG_B LS722122 3            ← 共 3 塊
LOG_D LS722122 0 <base64>   ← 第 0 塊
LOG_D LS722122 1 <base64>
LOG_D LS722122 2 <base64>
LOG_E LS722122 626          ← 原始 626 字元
```

- **必須用 base64**：AMOS 輸出含框線、ANSI、多空白，
  直接塞會有控制字元破壞序列埠。
- 每塊 base64 **400 字元**（PC 端已固定）。
- Jarvis 端重組上限 **8192 字元**，超過會丟棄後續。
- 分塊之間給 **10ms** 間隔（PC 端已做）。

### 頻道限制（重要）

ESP-NOW 雙方**必須同一個 Wi-Fi 頻道**。

- Jarvis 跟著它連上的 AP 走（目前是 `ParrotBird`）
- **東尼必須連同一個 AP**，或手動 `esp_wifi_set_channel()` 設成同頻道
- 否則封包收不到（不會報錯，只是靜靜失敗）

---

## 四、USB 序列側（對公司電腦）

**115200 8N1，UTF-8，一行一指令，`\n` 結尾。**

### PC → 東尼（東尼要處理）

| 指令 | 回應 |
|---|---|
| `PING` | `PONG` |
| `INFO` | `INFO {"fw":"2.0","role":"responder","busy":false,"site":"","amos":true}` |
| `CHECK <SITE>` | `ACK CHECK <SITE>` 然後串流結果 |
| `CHECK <SITE> NOLT` | 同上，但跳過 LT ALL |
| `CANCEL` | `OK CANCEL` |

### 東尼 → PC（東尼要產生 / 轉發）

| 訊息 | 說明 |
|---|---|
| `ACK CHECK <SITE>` | 已收到，開始執行 |
| `PROG <0-99> <階段>` | 進度，每階段一行 |
| `LOG B <SITE> <base64長度>` | LOG 開始 |
| `LOG D <SITE> <序號> <base64>` | LOG 分塊 |
| `LOG E <SITE> <原始字元數>` | LOG 結束 |
| `ERR <CODE> <訊息>` | 失敗 |

錯誤碼：
```
ESPNOW_DOWN      ESP-NOW 未就緒
TEXT_TOO_LONG    超過 200 bytes
BUSY             已有任務在跑
AMOS_FAIL        AMOS 連線或執行失敗
UNKNOWN <指令>    不認得的指令
INTERNAL <訊息>   程式內部錯誤
```

### 機站名稱規則

`^[A-Za-z0-9_\-]{2,32}$`，一律轉大寫。

---

## 五、東尼的工作流程（韌體邏輯）

```
開機
 ├─ Wi-Fi STA 連上跟 Jarvis 同一個 AP
 ├─ esp_now_init() → 註冊 recv cb → 加入 Jarvis MAC 為 peer
 ├─ 開序列埠 115200
 └─ 主迴圈
      ├─ 收到 ESP-NOW CMD("CHECK xxx")
      │    └─ 序列埠寫出 "CHECK xxx"
      │    └─ 記住「目前任務」＝ xxx
      │
      └─ 序列埠收到 PC 的回應
           ├─ ACK / PROG → 可選擇轉給 Jarvis（目前不需要）
           └─ LOG B / LOG D / LOG E
                └─ 內容直接搬進 ESP-NOW 對應封包，轉給 Jarvis
                   （LOG D 的 base64 片段若超過 190 字元，
                     要再切小，否則會被 JV_TEXT_MAX 截斷）
```

### ★ 最關鍵的一點：LOG_D 的片段長度

PC 端每塊是 **400 字元 base64**。
但 ESP-NOW 單包 text 上限 **200 bytes**（扣掉前綴 `"<序號> "` 只剩約 190）。

**所以東尼必須把 400 字元的塊再切成 190 字元的小塊轉發。**

Jarvis 端會依序拼接，不需要知道東尼怎麼切的——
只要 `LOG_D` 的內容依序接起來就是完整 base64。

> 也就是說：`LOG_B` 的「總塊數」對 Jarvis 只是參考，
> 真正判斷結束是看 `LOG_E`。所以切幾塊都不影響正確性。

---

## 六、測試方式

### 只測 Jarvis ↔ 東尼（不需要公司電腦）

```bash
# 在 Jarvis 端看日誌
# 應該看到：
#   JVLINK: ESP-NOW 就緒，本機 MAC 24:58:7C:E9:48:D4
# 東尼發 CMD 給 Jarvis 後，Jarvis 印：
#   JVLINK: 送出命令: CHECK LS722122
```

### 只測東尼 ↔ 公司電腦（不需要 Jarvis）

```bash
# 在公司電腦用序列埠終端機（115200）
# 打 CHECK LS722122
# 應看到：ACK CHECK LS722122 / PROG ... / LOG B / LOG D / LOG E
```

### 全鏈路

喊 Jarvis：「叫東尼查 LS722122 告警」

---

## 七、已知風險

| 風險 | 說明 | 對策 |
|---|---|---|
| 頻道不同 | ESP-NOW 靜靜失敗，不報錯 | 兩邊連同一個 AP |
| 距離 | 室內 30~50m，透牆會掉 | 東尼放中間樓層 |
| base64 片段太長 | 400 字元 > 200 bytes 上限 | 東尼再切 190 字元 |
| LOG 過大 | Jarvis 上限 8192 字元 | PC 端已限制 64K，正常告警遠小於此 |
| 東尼斷線 | Jarvis 只會說「東尼還沒連上」 | 重開東尼 |

---

## 八、目前狀態

```
Jarvis     ✅ 已完成並燒錄（3,654,448 bytes，10-28 15:44）
           開機驗證：ESP-NOW 就緒、無崩潰、內部 RAM free=8971
公司電腦   ✅ 執行端 v2.0 完成，測試全通過（無需實機）
bridge     ✅ /wheel_log 端點上線，實測 3.1 秒回 35 字
東尼     ⬜ 韌體尚未開始
```
