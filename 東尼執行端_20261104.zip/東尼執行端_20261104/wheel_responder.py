# -*- coding: utf-8 -*-
"""
wheel_responder.py — 東尼 公司電腦端「執行端」核心
珠珢 / 2026-10-28

★ 實際流程（主人 15:39 澄清）

    ① 主人喊 Jarvis
    ② Jarvis →（ESP-NOW）→ 東尼：「查 LS722122 告警」
    ③ 東尼 →（USB 序列）→ 公司電腦：「CHECK LS722122」
    ④ 公司電腦執行 AMOS（LT ALL → ALT），把 LOG 經 USB 回給東尼
    ⑤ 東尼 →（ESP-NOW）→ Jarvis：告警內容
    ⑥ Jarvis 分析後簡短唸出

  所以公司電腦這一端是【被動執行端】：
    被動等指令 → 執行 → 回傳結果
    不是主動送話給 Jarvis。

★ 為什麼把邏輯抽成 Responder（不放在 tkinter 裡）
    可以在沒有視窗、沒有真板子的情況下單獨測試協定，
    這正是最容易出錯的地方。

協定（東尼 → PC，一行一指令，UTF-8，\\n 結尾）
------------------------------------------------
    PING                        → PONG
    INFO                        → INFO {json}
    CHECK <SITE>                → 開始查詢（預設先 LT ALL）
    CHECK <SITE> NOLT           → 只 ALT，不 LT ALL
    CANCEL                      → 取消目前任務

協定（PC → 東尼）
-------------------
    PONG                              ← PING 的回應
    INFO {json}                       ← 狀態
    ACK CHECK <SITE>                  ← 已收到，開始執行
    PROG <0-99> <階段>                ← 進度（每階段一行）
    LOG B <SITE> <base64長度>         ← 開始傳 LOG
    LOG D <SITE> <序號> <base64>      ← LOG 分塊（base64 避免特殊字元）
    LOG E <SITE> <原始字元數>         ← LOG 結束
    ERR <CODE> <訊息>                 ← 失敗
    OK CANCEL                         ← 已取消

  ★ LOG 用 base64：AMOS 輸出含框線、ANSI、空白對齊，
    直接塞序列埠容易被換行/控制字元破壞。base64 只有 [A-Za-z0-9+/=]。

  ★ 分塊大小 400 字元（base64）→ 115200 baud 下約 35ms/行，
    東尼端好緩衝，也不會讓 Jarvis 那邊等太久。
"""
import base64
import json
import os
import re
import threading
import time

CHUNK_CHARS = 400
MAX_LOG_CHARS = 64 * 1024        # 64K 字元上限，超過截斷（避免塞爆東尼）


class Responder:
    """收到指令 → 執行 AMOS → 回傳 LOG"""

    def __init__(self, conf, send_line, log=None, amos_factory=None):
        self.conf = conf or {}
        self.send_line = send_line          # callable(str) → 寫進序列埠
        self.log = log or (lambda m, t="sys": None)
        self.amos_factory = amos_factory    # 測試時可注入假物件

        self.busy = False
        self.site = ""
        self._cancel = threading.Event()
        self._thread = None
        self._lock = threading.Lock()

    # ---------- 對外 ----------
    def handle_line(self, line):
        """收到東尼一行指令。所有例外都在這裡吃掉，不能讓執行緒死掉。"""
        line = (line or "").strip()
        if not line:
            return
        self.log("← %s" % line, "rx")

        try:
            self._dispatch(line)
        except Exception as e:
            self.log("處理指令出錯：%r" % (e,), "err")
            try:
                self.send_line("ERR INTERNAL %s" % str(e)[:80].replace("\n", " "))
            except Exception:
                pass

    def cancel(self):
        self._cancel.set()
        return not self.busy

    def info(self):
        return {
            "fw": "2.0",
            "role": "responder",
            "busy": bool(self.busy),
            "site": self.site,
            "amos": bool(self.conf.get("script_user")),
        }

    # ---------- 分派 ----------
    # ★★★ 2026-10-28 17:24 修正（主人：「為啥現在 jarvis 一直說 公司電腦回報失敗 unknown」）
    #
    #   症狀：Jarvis 每幾秒就唸一次「公司電腦回報失敗（UNKNOWN）」。
    #
    #   原因：序列埠是雙向的。UI 送出 PING 之後，東尼會回 PONG；
    #         送出 CANCEL 之後回 OK CANCEL；
    #         而這些「回應」回到這裡的 _dispatch，
    #         被當成「未知指令」→ 又送出 ERR UNKNOWN → 東尼轉給 Jarvis。
    #         心跳每 15 秒一次，所以錯誤永無止境。
    #
    #   實測重現：
    #       收到 'PONG'      → 送出 ['ERR UNKNOWN PONG']
    #       收到 'OK CANCEL' → 送出 ['ERR UNKNOWN OK CANCEL']
    #
    #   修法：先認出「這是協定回應」就靜靜忽略，不回應。
    #         只有真正的指令才往下去判斷。
    #   ★ 注意：「CANCEL」是 PC 送給東尼的【指令】，
    #     不是回應；東尼的回應是「OK CANCEL」。
    #     所以這裡不能列 CANCEL，否則取消功能會失效。
    _RESPONSE_PREFIXES = (
        "PONG", "INFO ", "ACK ", "PROG ", "LOG BEGIN", "LOG END",
        "LOG B ", "LOG D ", "LOG E ", "OK ", "ERR ",
    )

    def _dispatch(self, line):
        up = line.upper()

        # ★ 先過濾「協定回應」（不是指令，直接忽略）
        for pre in self._RESPONSE_PREFIXES:
            if up.startswith(pre.upper()):
                return

        # ★ 保險：不認識的行最多回 3 次，之後靜默（防任何回圈）
        if not hasattr(self, "_unknown_cnt"):
            self._unknown_cnt = 0

        if up == "PING":
            self.send_line("PONG")
            return

        if up == "INFO":
            self.send_line("INFO " + json.dumps(self.info(), ensure_ascii=False))
            return

        if up == "CANCEL":
            if self.busy:
                self._cancel.set()
                self.log("收到取消要求", "err")
                self.send_line("OK CANCEL")
            else:
                self.send_line("OK CANCEL")
            return

        m = re.match(r"^CHECK\s+([A-Za-z0-9_\-]{2,32})(?:\s+(NOLT))?$", line, re.I)
        if m:
            site = m.group(1).upper()
            do_lt = not bool(m.group(2))
            self.start_check(site, do_lt)
            return

        # ★ 2026-11-04 主人新增：教東尼打站台 license
        #   指令格式：LICENSE <SITE>   例：LICENSE LS720446
        #   文件：LS720446_License_安裝指令.md（九步流程）
        lm = re.match(r"^LICEN[CS]E\s+([A-Za-z0-9_\-]{2,32})"
                      r"(?:\s+(DRYRUN))?$", line, re.I)
        if lm:
            site = lm.group(1).upper()
            dry = bool(lm.group(2))
            self.start_license(site, dry_run=dry)
            return

        # ★ 只回前 3 次，之後靜默（避免任何未預期行造成無限回圈）
        if self._unknown_cnt < 3:
            self._unknown_cnt += 1
            self.send_line("ERR UNKNOWN %s" % line[:40].replace("\n", " "))
            if self._unknown_cnt == 3:
                self.log("收到多次無法辨識的行，已停止回報", "err")

    # ---------- 開始查詢 ----------
    def start_check(self, site, do_lt=True):
        with self._lock:
            if self.busy:
                self.send_line("ERR BUSY %s" % self.site)
                self.log("還在查 %s，忽略新的 %s" % (self.site, site), "err")
                return False
            self.busy = True
            self.site = site
            self._cancel.clear()

        self.send_line("ACK CHECK %s" % site)
        self.log("── 開始查 %s（LT ALL=%s）──" % (site, do_lt), "amos")

        def worker():
            try:
                self._run(site, do_lt)
            except Exception as e:
                self.log("查詢失敗：%r" % (e,), "err")
                try:
                    self.send_line("ERR AMOS_FAIL %s"
                                   % str(e)[:100].replace("\n", " "))
                except Exception:
                    pass
            finally:
                with self._lock:
                    self.busy = False
                    self.site = ""

        self._thread = threading.Thread(target=worker, daemon=True)
        self._thread.start()
        return True

    def _prog(self, pct, stage):
        try:
            self.send_line("PROG %d %s" % (max(0, min(99, int(pct))), stage))
        except Exception:
            pass

    # ---------- 打 license（2026-11-04 新增）----------
    def start_license(self, site, dry_run=False):
        """跑一次 license 安裝。流程與查告警共用同一個 busy 鎖，
        所以不會兩個任務同時佔著跳板機。"""
        with self._lock:
            if self.busy:
                self.send_line("ERR BUSY %s" % self.site)
                self.log("還在忙 %s，忽略 license %s" % (self.site, site), "err")
                return False
            self.busy = True
            self.site = site
            self._cancel.clear()

        self.send_line("ACK LICENSE %s" % site)
        self.log("── 開始打 license %s（dry_run=%s）──" % (site, dry_run), "amos")

        def worker():
            try:
                self._run_license(site, dry_run)
            except Exception as e:
                self.log("license 失敗：%r" % (e,), "err")
                try:
                    self.send_line("ERR LICENSE_FAIL %s"
                                   % str(e)[:100].replace("\n", " "))
                except Exception:
                    pass
            finally:
                with self._lock:
                    self.busy = False
                    self.site = ""

        self._thread = threading.Thread(target=worker, daemon=True)
        self._thread.start()
        return True

    def _run_license(self, site, dry_run=False):
        """實際跑 license_flow，並把結果 LOG 回傳給東尼。

        ★ 沿用查告警同一套 LOG B/D/E 協定，所以東尼與 Jarvis 完全不用改
          就能收到並唸出結果。
        """
        import license_flow as LF

        def _raw(m):
            self.log(m, "raw")

        lines = []

        def _note(m):
            lines.append(str(m))
            self.log(m, "amos")

        flow = LF.LicenseFlow(
            self.conf,
            log=_note,
            raw_log=_raw,
            on_prog=lambda p, s: self._prog(p, s),
        )
        try:
            res = flow.install(site, dry_run=dry_run)
        finally:
            try:
                flow.close()
            except Exception:
                pass

        if self._cancel.is_set():
            raise RuntimeError("已取消")

        # 組一份人看得懂的文字報告（東尼會 base64 傳給 Jarvis）
        buf = []
        buf.append("===== LICENSE %s =====" % site)
        buf.append("結果      : %s" % ("成功" if res.get("ok") else "失敗"))
        if res.get("dry_run"):
            buf.append("模式      : DRY-RUN（沒有連任何機器）")
        buf.append("本機檔案  : %s" % res.get("local", "?"))
        buf.append("檔案大小  : %s bytes" % res.get("size", "?"))
        if not res.get("dry_run"):
            buf.append("LicenseState : %s" % (res.get("license_state") or "?"))
            buf.append("FingerPrint  : %s" % (res.get("fingerprint") or "?"))
        buf.append("")
        buf.append("--- 步驟記錄 ---")
        for ln in lines:
            buf.append(ln)
        text = "\n".join(buf)

        self._send_log(site, text)
        return res

    def _run(self, site, do_lt):
        # ★ 2026-10-29 15:12：raw_log 讓 AMOS 每一行原始輸出都進畫面
        def _raw(m):
            self.log(m, "raw")

        if self.amos_factory:
            cl = self.amos_factory(self.conf, lambda m: self._log_amos(m))
        else:
            import amos_client as A
            cl = A.AmosClient(self.conf,
                              log=lambda m: self._log_amos(m),
                              raw_log=_raw)

        try:
            self._prog(5, "連線跳板機")
            cl.connect()

            if self._cancel.is_set():
                self._finish_cancel()
                return

            self._prog(25, "進 AMOS")
            # read_alarms 內部自己會 LT ALL + ALT
            parsed = cl.read_alarms(site, do_lt=do_lt)

            if self._cancel.is_set():
                self._finish_cancel()
                return

            self._prog(80, "整理結果")
            raw = parsed.get("raw") or ""

            # 附一段可讀摘要在最前面，Jarvis 分析時看得懂
            header = self._summary_header(site, parsed)
            text = header + "\n" + ("=" * 56) + "\n" + raw

            self._send_log(site, text)
            self._prog(99, "完成")
            self.log("已回傳 %s 的 LOG（%d 字元）" % (site, len(text)), "rx")
        finally:
            try:
                cl.quit_amos()
            except Exception:
                pass
            try:
                cl.close()
            except Exception:
                pass

    def _run_sync(self, site, do_lt=True):
        """同步跑一次查詢並回傳 parsed（給第二條路由 HTTP 用）。

        ★ 2026-10-29 15:25：主人要把 Jarvis 帶回家，ESP-NOW 會斷，
          所以 bridge 要能直接叫公司電腦查。這條路不經東尼，
          但仍共用同一套 AMOS 邏輯，並把每一行原始輸出送進畫面。
        """
        def _raw(m):
            self.log(m, "raw")

        if self.amos_factory:
            cl = self.amos_factory(self.conf, lambda m: self._log_amos(m))
        else:
            import amos_client as A
            cl = A.AmosClient(self.conf,
                              log=lambda m: self._log_amos(m),
                              raw_log=_raw)

        self.log("── [直接查詢] %s（不經東尼）──" % site, "amos")
        try:
            self._prog(5, "連線跳板機")
            cl.connect()
            if self._cancel.is_set():
                raise RuntimeError("已取消")
            self._prog(30, "AMOS 查詢")
            parsed = cl.read_alarms(site, do_lt=do_lt)
            self._prog(95, "整理結果")
            n = parsed.get("total", 0)
            self.log("直接查詢完成：%s 共 %d 個告警" % (site, n), "rx")
            return parsed
        finally:
            try:
                cl.quit_amos()
            except Exception:
                pass
            try:
                cl.close()
            except Exception:
                pass

    def _finish_cancel(self):
        self.log("任務已取消", "err")
        try:
            self.send_line("OK CANCEL")
        except Exception:
            pass

    def _log_amos(self, msg):
        """把 AmosClient 的日誌轉成進度回報（也順便顯示在 UI）"""
        self.log(msg, "amos")
        # 粗估百分比：連線階段 5~25，amos 30~75
        if "跳板機" in msg:
            self._prog(8, "跳板機")
        elif "腳本機" in msg:
            self._prog(16, "腳本機")
        elif "AMOS" in msg or "amos" in msg:
            self._prog(30, "AMOS")
        elif "LT ALL" in msg:
            self._prog(45, "LT ALL")
        elif "ALT" in msg:
            self._prog(65, "ALT")

    def _summary_header(self, site, parsed):
        alarms = parsed.get("alarms") or []
        total = parsed.get("total", len(alarms))
        crit = parsed.get("critical", 0)
        major = parsed.get("major", 0)
        lines = ["SITE: %s" % site,
                 "TIME: %s" % time.strftime("%Y-%m-%d %H:%M:%S"),
                 "TOTAL: %d (CRITICAL: %d, MAJOR: %d)" % (total, crit, major)]
        if not alarms:
            lines.append("ALARMS: none")
        else:
            lines.append("ALARMS:")
            for i, a in enumerate(alarms[:30], 1):
                lines.append("  %2d. [%s] %s | %s | %s"
                             % (i, a["sev"], a["time"], a["problem"], a["mo"]))
            if len(alarms) > 30:
                lines.append("  ... 還有 %d 筆" % (len(alarms) - 30))
        return "\n".join(lines)

    # ---------- 傳 LOG ----------
    def _send_log(self, site, text):
        if len(text) > MAX_LOG_CHARS:
            text = text[:MAX_LOG_CHARS] + "\n...(已截斷)"
            self.log("LOG 超過 %d 字元，已截斷" % MAX_LOG_CHARS, "err")

        b = base64.b64encode(text.encode("utf-8")).decode("ascii")
        self.send_line("LOG B %s %d" % (site, len(b)))

        seq = 0
        for i in range(0, len(b), CHUNK_CHARS):
            if self._cancel.is_set():
                self._finish_cancel()
                return
            self.send_line("LOG D %s %d %s" % (site, seq, b[i:i + CHUNK_CHARS]))
            seq += 1
            time.sleep(0.01)       # 給東尼一點時間緩衝

        self.send_line("LOG E %s %d" % (site, len(text)))
