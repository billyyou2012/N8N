# -*- coding: utf-8 -*-
"""
little_wheel_ui.py — 東尼 公司電腦端「執行端」
珠珢 / 2026-10-28  v2.0

★ 實際流程（主人 15:39 澄清）

    ① 主人喊 Jarvis
    ② Jarvis ─ESP-NOW→ 東尼：「查 LS722122 告警」
    ③ 東尼 ─USB→ 公司電腦：「CHECK LS722122」
    ④ 公司電腦跑 AMOS（LT ALL → ALT），LOG 經 USB 回東尼
    ⑤ 東尼 ─ESP-NOW→ Jarvis
    ⑥ Jarvis 分析後簡短唸出

  公司電腦是【被動執行端】：等指令 → 執行 → 回傳。
  不是主動送話給 Jarvis（那是 v1.0 的錯誤方向）。

★ 這個視窗的用途
  · 顯示連線狀態（東尼有沒有接上）
  · 顯示目前在做什麼（進度、機站、階段）
  · 保留手動輸入機站 → 可獨立測試（不經 Jarvis）
  · 完整記錄，出問題時可直接複製給人看
"""
import io
import json
import os
import socket
import sys
import threading
import time
import tkinter as tk
from tkinter import messagebox, ttk

from wheel_responder import Responder

APP = "東尼執行端"
VER = "2.5"

# ★ 2026-10-30：PyInstaller onefile 的 __file__ 指向臨時解壓目錄（sys._MEIPASS），
#   程式一關整個目錄就刪掉 → 存進去的帳密隔次開機就不見（主人回報「存不起來」）。
#   打包時要改用 exe 自己所在的資料夾；開發時照舊用 __file__。
if getattr(sys, "frozen", False):
    HERE = os.path.dirname(os.path.abspath(sys.executable))
else:
    HERE = os.path.dirname(os.path.abspath(__file__))
CONF_PATH = os.path.join(HERE, "config.json")

DEFAULT_CONF = {
    # ---- 東尼（USB 序列埠）----
    "transport": "serial",
    "serial_port": "AUTO",
    "baud": 115200,
    "tcp_host": "192.168.1.50",
    "tcp_port": 9000,
    "auto_reconnect": True,

    # ---- AMOS ----
    "jump_host": "10.76.191.171",
    "jump_user": "",
    "jump_pass": "",
    "script_host": "10.76.217.22",
    "script_user": "",
    "script_pass": "",
    "do_lt_all": True,
    "last_site": "",

    # ---- 第二條路由（Jarvis 不在時，bridge 直接叫這台查）----
    #   ★ 2026-10-29 15:25 主人需求：
    #     Jarvis 帶回家後 ESP-NOW 斷線，仍要能查 → bridge 走內網打這台。
    "exec_enabled": True,
    "exec_port": 8788,
    "exec_token": "",
    "bridge_url": "",          # 例 http://10.64.116.13:8778（開機自動登記用）

    # ---- 外觀 ----
    "font": "Microsoft JhengHei UI",
    "font_size": 11,
}


def load_conf():
    c = dict(DEFAULT_CONF)
    try:
        if os.path.exists(CONF_PATH):
            d = json.load(io.open(CONF_PATH, encoding="utf-8-sig"))
            if isinstance(d, dict):
                c.update(d)
    except Exception as e:
        print("config 讀取失敗，用預設值:", repr(e)[:100])
    return c


def save_conf(c):
    """寫入 config.json。回傳 (ok, detail)，detail 給畫面顯示用。

    ★ 2026-10-30：原本只印 console，打包成 exe 後看不到，
      帳密存不起來時完全沒有線索。現在把原因帶回去給呼叫端。
    """
    try:
        io.open(CONF_PATH, "w", encoding="utf-8").write(
            json.dumps(c, ensure_ascii=False, indent=2))
        return True, CONF_PATH
    except Exception as e:
        print("config 儲存失敗:", repr(e)[:100])
        return False, "%s（%s）" % (type(e).__name__, CONF_PATH)


def list_ports():
    try:
        from serial.tools import list_ports as lp
        return [(p.device, p.description or "") for p in lp.comports()]
    except Exception:
        return []


def list_ports_full():
    """回傳 (device, description, hwid) 三欄，用來辨識晶片。"""
    try:
        from serial.tools import list_ports as lp
        return [(p.device, p.description or "", p.hwid or "")
                for p in lp.comports()]
    except Exception:
        return []


# ============================================================
#  ★★★ 2026-10-28 17:18 新增：智慧選埠
#
#  帶去公司電腦時，AUTO 不能盲選「第一個」——
#  公司常還接著條碼機、數據機、UPS 等序列裝置，
#  選錯就會明明插好卻顯示「未連接！」。
#
#  依晶片特徵排序：
#    ① CP210x / Silicon Labs  ← 東尼就是這顆（實測 10C4:EA60）
#    ② CH340 / CH341
#    ③ USB 序列（generic）
#    ④ 其他
# ============================================================
_WHEEL_HINTS = (
    ("cp210", 0), ("silicon labs", 0),
    ("ch340", 1), ("ch341", 1),
    ("10c4:ea60", 0), ("1a86:7523", 1),
    ("usb serial", 3), ("usb-serial", 3), ("usb 序列", 3),
)

# ★ 2026-10-28 17:33：這些「一定不是東尼」，直接排除不選。
#   現場實例：Intel(R) Active Management Technology - SOL 佔用 COM3，
#   程式卻把它當成候選 → 白等 PING 逾時，還顯示誤導訊息。
_PORT_BLACKLIST = (
    "active management technology",   # Intel AMT 管理埠
    "amt - sol", "amt sol",
    "intel(r) active management",
    "bluetooth", "藍牙", "bluetooth 序列",
    "virtual serial", "虛擬序列",
    "modem", "數據機", "傳真",
    "com0com", "vspd",
    "usb serial port for x",          # 某些虛擬埠
)


def _is_blacklisted(desc, hwid):
    """True = 這個埠一定不是東尼"""
    blob = ("%s %s" % (desc, hwid)).lower()
    for bad in _PORT_BLACKLIST:
        if bad in blob:
            return True
    return False


def _port_looks_valid(port):
    """設定裡的埠還能用嗎？

    ★ 2026-10-28 17:40：v2.0 會把誤選的 COM3(Intel AMT) 寫進 config，
      之後每次啟動就死守那個埠。這裡把它擋掉，退回 AUTO 重新找。
    回傳 (ok, 原因)
    """
    if not port:
        return False, "未設定"
    ports = list_ports_full()
    names = [d for d, _desc, _hw in ports]
    if port not in names:
        return False, "%s 現在不存在" % port
    for d, desc, hwid in ports:
        if d == port and _is_blacklisted(desc, hwid):
            return False, "%s 是 %s（不是東尼）" % (port, desc)
    return True, ""


def _run_ps(script, timeout=12):
    """在視窗程式裡跑 PowerShell，不彈黑窗"""
    try:
        import subprocess
        kw = {}
        if sys.platform == "win32":
            # 0x08000000 = CREATE_NO_WINDOW
            kw["creationflags"] = 0x08000000
        r = subprocess.run(
            ["powershell", "-NoProfile", "-NonInteractive", "-Command", script],
            capture_output=True, timeout=timeout, **kw)
        out = r.stdout or b""
        try:
            return out.decode("utf-8", "replace")
        except Exception:
            return out.decode("big5", "replace")
    except Exception:
        return ""


def _list_problem_devices():
    """列出裝置管理員裡「有問題」的裝置（黃色驚嘆號 / 未知裝置）

    ★ 沒裝 CP210x 驅動時，板子會變成「未知裝置」或帶錯誤碼的裝置，
      這種情況下 VID_10C4 可能查不到，但這裡看得到。
    """
    ps = ("Get-PnpDevice -PresentOnly -ErrorAction SilentlyContinue | "
          "Where-Object { $_.Status -ne 'OK' -and $_.Class -ne 'SoftwareDevice' } | "
          "ForEach-Object { \"$($_.Status)|$($_.Class)|$($_.FriendlyName)\" }")
    out = _run_ps(ps)
    return [ln.strip() for ln in out.splitlines() if ln.strip()]


def diagnose_usb(log=None):
    """診斷「插了東尼卻找不到」到底卡在哪一關。

    回傳一個狀態字串：
      "ok"         有 COM 埠也有驅動
      "no_driver"  USB 看得到 CP210x，但沒有 COM 埠 → 缺驅動
      "no_device"  USB 完全看不到 CP210x → 線/孔/板子
      "unknown"    查不到
    """
    def say(msg, tag="info"):
        if log:
            log(msg, tag)

    # ① USB 上有沒有 CP210x（VID 10C4 PID EA60）
    ps = ("Get-PnpDevice -PresentOnly -ErrorAction SilentlyContinue | "
          "Where-Object { $_.InstanceId -match 'VID_10C4' } | "
          "ForEach-Object { \"$($_.Status)|$($_.FriendlyName)\" }")
    out = _run_ps(ps)
    usb_hits = [ln.strip() for ln in out.splitlines() if ln.strip()]

    # ② 有沒有 COM 埠
    comports = list_ports_full()

    say("")
    say("── 現場診斷 ──", "info")

    if usb_hits:
        for h in usb_hits:
            say("  USB 有看到: %s" % h, "info")
    else:
        say("  USB 完全沒看到 CP210x（VID 10C4）", "err")

    say("  系統 COM 埠: %d 個" % len(comports), "info")
    for d, desc, _hw in comports:
        say("    %s  %s" % (d, desc), "info")

    # ★ 有問題的裝置（沒驅動的板子會出現在這裡）
    probs = _list_problem_devices()
    if probs:
        say("  有問題的裝置 %d 個：" % len(probs), "err")
        for p in probs[:8]:
            say("    %s" % p, "err")

    # ③ 判斷
    if usb_hits and not comports:
        say("", "info")
        say("★ 結論：線和板子都正常，是【這台電腦缺 CP210x 驅動】", "err")
        say("  修法（任一種）：", "err")
        say("   A. 插上東尼後，開「裝置管理員」找有黃色驚嘆號的裝置", "err")
        say("      → 右鍵「更新驅動程式」→ 自動搜尋", "err")
        say("   B. 或用手機熱點把 Windows Update 跑一次", "err")
        say("   C. 或請 IT 裝 Silicon Labs CP210x VCP 驅動", "err")
        say("  裝好後 COM 埠會出現在「連接埠 (COM 和 LPT)」底下", "err")
        return "no_driver"

    if usb_hits and comports:
        say("", "info")
        say("★ 結論：驅動正常，但偵測到的埠都不是東尼", "err")
        say("  請在「設定」裡手動指定正確的 COM 埠號", "err")
        return "ok"

    # USB 完全沒有
    say("", "info")
    if probs:
        say("★ 結論：USB 上「有東西」但沒有正常驅動 —— 很可能是【缺 CP210x 驅動】", "err")
        say("  上面那些「有問題的裝置」就是它。修法：", "err")
        say("   A. 裝置管理員 → 對它按右鍵 → 更新驅動程式 → 自動搜尋", "err")
        say("   B. 或請 IT 安裝 Silicon Labs CP210x VCP Driver", "err")
        say("   C. 裝好後會出現在「連接埠 (COM 和 LPT)」", "err")
        return "no_driver"

    say("★ 結論：這台電腦【完全沒偵測到東尼】", "err")
    say("  也就是說問題不在軟體、也不在驅動，是硬體這一段：", "err")
    say("   1. USB 線是「純充電線」→ 換一條有資料的線", "err")
    say("      （原廠線多半只有充電；用手機傳輸線最保險）", "err")
    say("   2. 換一個 USB 孔（避開 USB hub、避開鍵盤上的孔）", "err")
    say("   3. 東尼上的燈有沒有亮？沒亮 = 沒通電", "err")
    say("   4. 同一條線+同一塊板，插回自己電腦若正常", "err")
    say("      → 就是公司電腦的 USB 孔或資安政策擋住", "err")
    return "no_device"


def pick_wheel_port():
    """挑出最可能是東尼的序列埠。

    回傳 (device, desc, score)。
      score 0 = CP210x（東尼就是這顆）
      score 1 = CH340
      score 3 = 其他 USB 序列
      score 9 = 看不出來（勉強用）
      score -2 = 只有黑名單裝置（Intel AMT 等）→ 呼叫端應報「沒偵測到」
      score -1 = 完全沒有序列埠
    """
    allp = list_ports_full()

    # ★ 先剔除「一定不是東尼」的（Intel AMT、藍牙、數據機…）
    cands = []
    blocked = []
    for dev, desc, hwid in allp:
        if _is_blacklisted(desc, hwid):
            blocked.append((dev, desc))
            continue
        blob = ("%s %s" % (desc, hwid)).lower()
        score = 9
        for key, sc in _WHEEL_HINTS:
            if key in blob:
                score = min(score, sc)
        cands.append((score, dev, desc))

    if not cands:
        if blocked:
            # 有埠，但全是黑名單 → 告訴主人「這不是東尼」
            return None, "", -2
        return None, "", -1

    cands.sort(key=lambda t: (t[0], t[1]))
    score, dev, desc = cands[0]
    return dev, desc, score


# ============================================================
#  傳輸層
# ============================================================
class SerialLink:
    def __init__(self, port, baud=115200):
        self.port = port
        self.baud = baud
        self.ser = None
        self.ok = False
        self.last_err = ""
        self.name = "(未連線)"
        self._buf = b""
        self.lock = threading.Lock()

    def open(self):
        try:
            import serial
        except Exception:
            self.last_err = "沒有 pyserial"
            return False
        try:
            self.ser = serial.Serial(self.port, self.baud, timeout=0.05)
            time.sleep(0.2)
            try:
                self.ser.reset_input_buffer()
            except Exception:
                pass
            self.ok = True
            self.name = "%s @ %d" % (self.port, self.baud)
            self.last_err = ""
            return True
        except Exception as e:
            self.ok = False
            self.last_err = str(e)
            return False

    def close(self):
        self.ok = False
        try:
            if self.ser:
                self.ser.close()
        except Exception:
            pass
        self.ser = None

    def write_line(self, text):
        if not self.ser:
            return False
        try:
            with self.lock:
                self.ser.write((text + "\n").encode("utf-8"))
                self.ser.flush()
            return True
        except Exception as e:
            self.last_err = str(e)
            return False

    def read_ready(self):
        if not self.ser:
            return []
        try:
            n = self.ser.in_waiting
            if n:
                self._buf += self.ser.read(n)
        except Exception as e:
            self.last_err = str(e)
            return []
        out = []
        while b"\n" in self._buf:
            line, self._buf = self._buf.split(b"\n", 1)
            s = line.decode("utf-8", "replace").strip()
            if s:
                out.append(s)
        if len(self._buf) > 16384:
            self._buf = b""
        return out


class TcpLink(SerialLink):
    def __init__(self, host, port):
        super().__init__("%s:%d" % (host, port))
        self.host = host
        self.tport = port
        self.sock = None

    def open(self):
        try:
            self.sock = socket.create_connection((self.host, self.tport), timeout=4)
            self.sock.settimeout(0.05)
            self.ok = True
            self.name = "%s:%d" % (self.host, self.tport)
            self.last_err = ""
            return True
        except Exception as e:
            self.ok = False
            self.last_err = str(e)
            return False

    def close(self):
        self.ok = False
        try:
            if self.sock:
                self.sock.close()
        except Exception:
            pass
        self.sock = None

    def write_line(self, text):
        if not self.sock:
            return False
        try:
            with self.lock:
                self.sock.sendall((text + "\n").encode("utf-8"))
            return True
        except Exception as e:
            self.last_err = str(e)
            return False

    def read_ready(self):
        if not self.sock:
            return []
        try:
            d = self.sock.recv(4096)
            if d:
                self._buf += d
            else:
                self.ok = False
                self.last_err = "對端關閉"
                return []
        except socket.timeout:
            pass
        except Exception as e:
            self.last_err = str(e)
            self.ok = False
            return []
        out = []
        while b"\n" in self._buf:
            line, self._buf = self._buf.split(b"\n", 1)
            s = line.decode("utf-8", "replace").strip()
            if s:
                out.append(s)
        return out


# ============================================================
#  主視窗
# ============================================================
class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.conf = load_conf()
        self.title("%s  v%s" % (APP, VER))
        self.geometry("880x640")
        self.minsize(780, 560)

        self.link = None
        self.connected = False
        self.resp = None
        self.last_ping = 0.0
        self.started = time.time()
        # ★ 握手與熱插拔狀態
        self.handshake_ok = False
        self.handshake_ok_flag = False
        self.handshake_deadline = 0.0
        self.ping_miss = 0
        self.last_port_check = 0.0

        fs = self.conf.get("font_size", 11)
        fam = self.conf.get("font", "Microsoft JhengHei UI")
        self.F = (fam, fs)
        self.FB = (fam, fs, "bold")
        self.FS = (fam, max(9, fs - 1))
        self.FM = ("Consolas", max(9, fs - 1))

        self._build()
        # ★ 2026-10-29 15:25：第二條路由（不經 Jarvis、不經東尼）
        #   Jarvis 帶回家後 ESP-NOW 會斷，靠這個讓 bridge 直接叫這台查。
        #   失敗只印一行，絕不影響主程式（USB 那條路照舊）。
        self.execd = None
        try:
            if self.conf.get("exec_enabled", True):
                import wheel_httpd as WH
                self.execd = WH.ExecHttpd(
                    self.conf,
                    responder=getattr(self, "resp", None),
                    port=self.conf.get("exec_port", 8788),
                    token=self.conf.get("exec_token", "") or "",
                    log=lambda m: self._log(m, "sys"),
                )
                if self.execd.start():
                    self._log("第二條路由已開（bridge 可直接查，不需 Jarvis）", "sys")
                    bu = (self.conf.get("bridge_url") or "").strip()
                    if bu:
                        self.after(2500, lambda: WH.register_to_bridge(
                            bu, self.execd.port, log=lambda m: self._log(m, "sys")))
        except Exception as _e:
            self._log("第二條路由啟動失敗（不影響 USB 查詢）：%r" % (_e,), "err")

        self.after(100, self._tick)
        self.after(300, self._auto_connect)

    # ---------- 版面 ----------
    def _build(self):
        pad = 10

        # ===== 頂列 =====
        top = tk.Frame(self)
        top.pack(fill="x", padx=pad, pady=(pad, 0))
        self.lbl_dot = tk.Label(top, text="●", font=(self.F[0], 14), fg="#c0392b")
        self.lbl_dot.pack(side="left")
        self.lbl_state = tk.Label(top, text="未連接！", font=self.FB, anchor="w")
        self.lbl_state.pack(side="left", padx=(4, 12))
        self.lbl_info = tk.Label(top, text="", font=self.FS, fg="#555", anchor="w")
        self.lbl_info.pack(side="left", fill="x", expand=True)
        self.btn_conn = tk.Button(top, text="連線", font=self.F, width=8,
                                  command=self.toggle_conn)
        self.btn_conn.pack(side="right")
        tk.Button(top, text="設定", font=self.F, width=6,
                  command=self.open_settings).pack(side="right", padx=(0, 6))

        # ===== 目前任務 =====
        sbox = tk.LabelFrame(self, text=" 目前任務 ", font=self.F)
        sbox.pack(fill="x", padx=pad, pady=(pad, 0))

        self.lbl_task = tk.Label(sbox, text="等待指令（由 Jarvis 透過東尼下達）",
                                 font=self.FB, anchor="w", fg="#666")
        self.lbl_task.pack(fill="x", padx=10, pady=(8, 2))

        self.pb = ttk.Progressbar(sbox, mode="determinate", maximum=100)
        self.pb.pack(fill="x", padx=10, pady=(0, 6))

        self.lbl_stage = tk.Label(sbox, text="", font=self.FS, anchor="w", fg="#777")
        self.lbl_stage.pack(fill="x", padx=10, pady=(0, 8))

        # ===== 手動測試 =====
        mbox = tk.LabelFrame(self, text=" 手動測試（不經 Jarvis，直接測 AMOS） ", font=self.F)
        mbox.pack(fill="x", padx=pad, pady=(8, 0))
        r = tk.Frame(mbox)
        r.pack(fill="x", padx=8, pady=8)
        tk.Label(r, text="機站名稱", font=self.F).pack(side="left")
        self.var_site = tk.StringVar(value=self.conf.get("last_site", ""))
        e = tk.Entry(r, textvariable=self.var_site, font=self.F, width=20)
        e.pack(side="left", padx=(6, 6))
        e.bind("<Return>", lambda ev: self.manual_check())
        tk.Button(r, text="執行查詢", font=self.F, width=10,
                  command=self.manual_check).pack(side="left")
        self.var_lt = tk.BooleanVar(value=bool(self.conf.get("do_lt_all", True)))
        tk.Checkbutton(r, text="先 LT ALL", font=self.FS,
                       variable=self.var_lt).pack(side="left", padx=(10, 0))
        self.btn_cancel = tk.Button(r, text="取消", font=self.FS, width=6,
                                    state="disabled", command=self.do_cancel)
        self.btn_cancel.pack(side="left", padx=(10, 0))

        # ===== 記錄 =====
        lbox = tk.LabelFrame(self, text=" 記錄 ", font=self.F)
        lbox.pack(fill="both", expand=True, padx=pad, pady=(8, pad))

        self.log = tk.Text(lbox, font=self.FM, wrap="word", state="disabled",
                           bg="#1e1e1e", fg="#d4d4d4")
        sb = tk.Scrollbar(lbox, command=self.log.yview)
        self.log.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        self.log.pack(side="left", fill="both", expand=True)

        self.log.tag_config("tx", foreground="#4ec9b0")
        self.log.tag_config("rx", foreground="#dcdcaa")
        self.log.tag_config("err", foreground="#f48771")
        self.log.tag_config("sys", foreground="#808080")
        self.log.tag_config("amos", foreground="#569cd6")
        # ★ 2026-10-29 15:12：AMOS 原始輸出（灰白，跟階段訊息區隔）
        self.log.tag_config("raw", foreground="#c8c8c8")

        bar = tk.Frame(self)
        bar.pack(fill="x", side="bottom")
        self.lbl_foot = tk.Label(bar, text="", font=self.FS, fg="#777", anchor="w")
        self.lbl_foot.pack(side="left", padx=pad, pady=2)

    # ---------- 記錄 ----------
    def _log(self, msg, tag="sys"):
        ts = time.strftime("%H:%M:%S")
        self.log.configure(state="normal")
        self.log.insert("end", "[%s] %s\n" % (ts, msg), tag)
        self.log.see("end")
        if int(self.log.index("end-1c").split(".")[0]) > 3000:
            self.log.delete("1.0", "800.0")
        self.log.configure(state="disabled")

    def _log_t(self, msg, tag="sys"):
        """從背景執行緒記錄"""
        self.after(0, lambda: self._log(msg, tag))

    # ---------- 連線 ----------
    def _make_link(self):
        if self.conf.get("transport") == "tcp":
            return TcpLink(self.conf.get("tcp_host"),
                           int(self.conf.get("tcp_port", 9000)))
        port = self.conf.get("serial_port", "AUTO")

        # ★ 2026-10-28 17:40：舊版可能把 Intel AMT 之類的埠存進設定，
        #   造成之後每次啟動都死守那個不可能的埠 → 自動退回 AUTO。
        if port not in ("", "AUTO", None):
            ok, why = _port_looks_valid(port)
            if not ok:
                self._log("設定的 %s 不能用（%s）→ 改為自動偵測" % (port, why), "err")
                port = "AUTO"
                self.conf["serial_port"] = "AUTO"
                try:
                    save_conf(self.conf)   # 自動記憶序號，失敗不影響連線
                except Exception:
                    pass

        if port in ("", "AUTO", None):
            # ★ 2026-10-28 17:18：不再盲選第一個，改依晶片特徵挑
            dev, desc, score = pick_wheel_port()
            if not dev:
                if score == -2:
                    # 有序列埠，但全是 Intel AMT / 藍牙這類 → 東尼沒被認到
                    self._log("★ 沒偵測到東尼（只找到不相關的序列埠）", "err")
                    for d, dd in list_ports():
                        if _is_blacklisted(dd or "", ""):
                            self._log("    %s  %s  ← 不是東尼" % (d, dd), "err")
                    # ★ 2026-10-28 17:36：自動跑現場診斷，講清楚卡在哪
                    try:
                        diagnose_usb(self._log)
                    except Exception as _e:
                        self._log("  診斷失敗：%r" % (_e,), "err")
                else:
                    self._log("找不到任何序列埠 —— 請確認：", "err")
                    self._log("  1) 東尼已用 USB 插上", "err")
                    self._log("  2) 已安裝 CP210x 驅動（Silicon Labs）", "err")
                    try:
                        diagnose_usb(self._log)
                    except Exception:
                        pass
                return None

            port = dev
            if score == 0:
                self._log("自動選擇 %s（CP210x，應該就是東尼）" % port)
            elif score == 1:
                self._log("自動選擇 %s（CH340）" % port)
            elif score == 3:
                self._log("自動選擇 %s（USB 序列）" % port)
            else:
                self._log("自動選擇 %s —— 但認不出晶片型號" % port, "err")
                self._log("  若顯示未連接，請在設定裡手動指定埠號", "err")

            if desc:
                self._log("  裝置：%s" % desc)

            self.conf["serial_port"] = port
            save_conf(self.conf)   # 記住這個埠，下次優先
        return SerialLink(port, int(self.conf.get("baud", 115200)))

    def _auto_connect(self):
        self._log("%s v%s 啟動（被動執行端）" % (APP, VER))
        self._log("等 Jarvis 透過東尼下達 CHECK <機站名>")
        for d, desc in list_ports():
            self._log("  可用埠 %s  %s" % (d, desc))
        self.connect()

    def toggle_conn(self):
        self.disconnect() if self.connected else self.connect()

    def connect(self):
        if self.connected:
            return
        lk = self._make_link()
        if not lk:
            self._set_state(False, "找不到連線")
            return
        if not lk.open():
            self._set_state(False, "連線失敗")
            self._log("東尼連線失敗：%s" % lk.last_err, "err")
            self._hint()
            return
        # ★ 開埠成功還不算連上 —— 要先握手確認對方是東尼
        self.link = lk
        self.handshake_ok = False
        self.handshake_ok_flag = False
        self.ping_miss = 0
        self.last_port_check = time.time()
        self.handshake_deadline = time.time() + 2.5
        self._set_state("waiting", "序列埠已開 %s，正在確認東尼…" % lk.name)
        self._log("序列埠已開 %s，等待東尼回應 PING…" % lk.name)

        # 建立 Responder（握手成功後才會用到，先備好）
        self.resp = Responder(
            self.conf,
            send_line=self._send_line_safe,
            log=self._log_t,
        )
        # 送 PING 做握手
        lk.write_line("PING")

    def _send_line(self, line):
        # 不記錄 LOG 分塊與心跳（會洗版），只記關鍵
        if not (line.startswith("LOG D")) and not self._is_quiet(line):
            self._log("→ %s" % (line if len(line) <= 70 else line[:70] + "…"), "tx")
        if self.link and self.connected:
            return self.link.write_line(line)
        return False

    def _send_line_safe(self, line):
        """Responder 用的寫入：不要求已 connected（握手後即可用），
           但仍需 link 存在，否則回 False。"""
        if not self.link:
            return False
        if not (line.startswith("LOG D")) and not self._is_quiet(line):
            self._log("→ %s" % (line if len(line) <= 70 else line[:70] + "…"), "tx")
        ok = self.link.write_line(line)
        # ★ 2026-10-30：這些行是 responder 產生的，不會回流到 _on_line，
        #   所以在這裡補一次畫面更新（只認 PROG/LOG E/ERR/ACK/CANCEL）
        self._update_task_ui(line)
        return ok

    def _hint(self):
        self._log("── 排錯 ──", "err")
        self._log("1) USB 線是否只供電不傳資料？換一條", "err")
        self._log("2) 裝置管理員 → 連接埠(COM & LPT) 是否有新的 COM", "err")
        self._log("3) 沒看到 → 裝 CP210x 或 CH340 驅動", "err")
        self._log("4) 有看到 → 設定裡手動選那個 COM", "err")

    def disconnect(self):
        if self.link:
            try:
                self.link.close()
            except Exception:
                pass
        self.link = None
        self.resp = None
        self._set_state(False, "已斷線")
        self._log("東尼已斷線")

    def _set_state(self, ok, text, stage=None):
        """三態顯示
           ok=True       → 已連接東尼（綠色）
           ok=False      → 未連接！（紅色）
           ok="waiting"  → 正在確認…（橘色，握手還沒回來）
        """
        if ok == "waiting":
            self.connected = False
            self.lbl_dot.configure(fg="#e67e22")
            self.lbl_state.configure(text="正在確認東尼…")
            self.btn_conn.configure(text="斷線")
            self.lbl_foot.configure(text=text)
            return

        self.connected = bool(ok)
        self.lbl_dot.configure(fg="#27ae60" if ok else "#c0392b")
        self.lbl_state.configure(text="已連接東尼" if ok else "未連接！")
        self.btn_conn.configure(text="斷線" if ok else "連線")
        self.lbl_foot.configure(text=text)

    # ---------- 主迴圈 ----------
    def _tick(self):
        # ---------- 讀回應（握手期間也要讀！）----------
        if self.link:
            try:
                for line in self.link.read_ready():
                    self._on_line(line)
            except Exception as e:
                self._log("讀取失敗：%r" % (e,), "err")

        # ---------- 握手階段 ----------
        if self.link and not self.handshake_ok:
            if self.handshake_ok_flag:
                # PONG 回來了 → 確認是東尼
                self.handshake_ok = True
                self._set_state(True, self.link.name)
                self._log("✓ 東尼已連接（PING/PONG 確認）", "rx")
                self.lbl_info.configure(text="等待 INFO…")
                self._send_line_safe("INFO")
            elif time.time() > self.handshake_deadline:
                # 逾時 → 不算連上
                self._log("PING 無回應 → 判定未連接", "err")
                self._log("  可能原因：插的不是東尼／韌體沒在跑／"
                          "鮑率不對（應 115200）／別的裝置佔用此埠", "err")
                try:
                    self.link.close()
                except Exception:
                    pass
                self.link = None
                self.resp = None
                self._set_state(False, "PING 無回應（不是東尼？）")

        # ---------- 已連線：檢查斷線 ----------
        if self.link and self.connected:
            if not getattr(self.link, "ok", True):
                self._log("東尼斷線：%s" % getattr(self.link, "last_err", ""), "err")
                self._drop_link("連線中斷")

        # ---------- 熱插拔：每 3 秒確認埠還在 ----------
        now = time.time()
        if self.link and now - self.last_port_check > 3:
            self.last_port_check = now
            if not self._port_exists():
                self._log("序列埠已消失（東尼被拔掉）", "err")
                self._drop_link("未連接！")
                # 繼續偵測是否重新插上
                if self.conf.get("auto_reconnect"):
                    self.after(2000, self.connect)

        # ---------- 心跳 ----------
        if self.connected and now - self.last_ping > 15:
            self.last_ping = now
            if self.ping_miss >= 2:
                self._log("PING 連續 %d 次沒回 → 判定未連接" % self.ping_miss, "err")
                self._drop_link("未連接！")
            self.ping_miss += 1
            self._send_line("PING")

        self.after(100, self._tick)

    def _drop_link(self, text):
        """統一的斷線處理"""
        self.handshake_ok = False
        self.handshake_ok_flag = False
        self.ping_miss = 0
        self._set_state(False, text)
        try:
            if self.link:
                self.link.close()
        except Exception:
            pass
        self.link = None
        self.resp = None
        self.lbl_info.configure(text="")

    def _port_exists(self):
        """確認目前用的序列埠是否還存在（熱插拔偵測）"""
        if not self.link:
            return False
        port = getattr(self.link, "port", None)
        if not port:
            return True      # TCP 模式不做這個檢查
        try:
            names = [d for d, _ in list_ports()]
            return port in names
        except Exception:
            return True      # 查不到就假設還在，不要誤判

    # ★ 2026-10-30：心跳訊息不進記錄（每 15 秒一次，會洗版）
    _QUIET = ("PING", "PONG")

    @staticmethod
    def _is_quiet(line):
        return (line or "").strip().upper() in App._QUIET

    def _on_line(self, line):
        # LOG 分塊、心跳不記錄（會洗版）
        if not line.startswith("LOG D") and not self._is_quiet(line):
            self._log("← %s" % line, "rx")

        # ★ 握手：任何已知回應都算「對方是東尼」
        up0 = line.upper()
        if up0.startswith("PONG"):
            self.handshake_ok_flag = True
        elif up0.startswith("INFO ") or up0.startswith("OK ") or up0.startswith("ERR "):
            if not self.handshake_ok:
                self.handshake_ok_flag = True

        # 有回應就重置 PING 失敗計數
        self.ping_miss = 0

        if self.resp:
            self.resp.handle_line(line)

        # 只更新畫面，不動資料
        self._update_task_ui(line)

    def _update_task_ui(self, line):
        """依協定行更新「目前任務」區塊。

        ★ 2026-10-30：抽成獨立方法，讓「往外送」的回應也能更新畫面。
          原本只有 RX（從序列埠讀進來）會更新，導致 responder 自己
          產生的 PROG / LOG E 只寫記錄、不改標籤，查完了還顯示「查詢中…」。
          只認下面這幾種行，其他一概不理；任何 UI 例外都吞掉，
          絕不讓畫面問題影響資料傳輸。
        """
        try:
            up = (line or "").upper()
            if up.startswith("CHECK "):
                parts = line.split()
                site = parts[1] if len(parts) > 1 else "?"
                self.lbl_task.configure(text="查詢 %s 中…" % site, fg="#e67e22")
                self.pb["value"] = 0
                self.btn_cancel.configure(state="normal")
            elif up.startswith("PROG"):
                m = re.match(r"PROG\s+(\d+)\s*(.*)", line, re.I)
                if m:
                    self.pb["value"] = int(m.group(1))
                    self.lbl_stage.configure(text=m.group(2))
            elif up.startswith("LOG E"):
                self.pb["value"] = 100
                self.lbl_task.configure(text="已完成，LOG 已回傳給東尼", fg="#27ae60")
                self.lbl_stage.configure(text="等 Jarvis 分析")
                self.btn_cancel.configure(state="disabled")
            elif up.startswith("ERR "):
                self.lbl_task.configure(text="失敗：%s" % line[4:60], fg="#c0392b")
                self.btn_cancel.configure(state="disabled")
            elif up.startswith("CANCEL"):
                self.lbl_task.configure(text="已取消", fg="#777")
                self.btn_cancel.configure(state="disabled")
        except Exception:
            pass

    # ---------- 手動 ----------
    def manual_check(self):
        site = (self.var_site.get() or "").strip().upper()
        if not site:
            messagebox.showinfo("缺少機站", "請輸入機站名稱，例如 LS722122")
            return
        self.conf["last_site"] = site
        self.conf["do_lt_all"] = bool(self.var_lt.get())
        ok_save, _ = save_conf(self.conf)
        if not ok_save:
            self._log("⚠ 機站記憶沒寫進去（不影響這次查詢）", "err")

        if not self.connected or not self.resp:
            messagebox.showwarning("未連接！",
                                   "請先確認東尼已插上，且上方顯示「已連接東尼」。")
            return
        cmd = "CHECK %s" % site if self.var_lt.get() else "CHECK %s NOLT" % site
        self._send_line(cmd)
        # 本機直接餵給 Responder（模擬東尼下達）
        self.resp.handle_line(cmd)

    def do_cancel(self):
        if self.resp:
            self.resp.cancel()
        self._send_line("CANCEL")

    # ---------- 設定 ----------
    def open_settings(self):
        w = tk.Toplevel(self)
        w.title("設定")
        w.geometry("520x560")
        w.transient(self)
        w.grab_set()

        F, FS = self.F, self.FS
        pad = {"padx": 14, "pady": 3}

        nb = ttk.Notebook(w)
        nb.pack(fill="both", expand=True, padx=10, pady=10)

        # ==== AMOS ====
        t1 = tk.Frame(nb)
        nb.add(t1, text="  AMOS 連線  ")

        tk.Label(t1, text="跳板機（第一段 SSH）", font=self.FB).pack(anchor="w", **pad)
        f = tk.Frame(t1); f.pack(anchor="w", padx=14)
        v_jh = tk.StringVar(value=str(self.conf.get("jump_host", "")))
        v_ju = tk.StringVar(value=str(self.conf.get("jump_user", "")))
        v_jp = tk.StringVar(value=str(self.conf.get("jump_pass", "")))
        tk.Label(f, text="Host", font=FS).grid(row=0, column=0, sticky="w")
        tk.Entry(f, textvariable=v_jh, font=FS, width=20).grid(row=0, column=1, padx=4)
        tk.Label(f, text="帳號", font=FS).grid(row=1, column=0, sticky="w")
        tk.Entry(f, textvariable=v_ju, font=FS, width=20).grid(row=1, column=1, padx=4)
        tk.Label(f, text="密碼", font=FS).grid(row=2, column=0, sticky="w")
        tk.Entry(f, textvariable=v_jp, font=FS, width=20, show="*").grid(row=2, column=1, padx=4)

        tk.Label(t1, text="腳本機（第二段 SSH）", font=self.FB).pack(anchor="w", pady=(12, 3))
        f2 = tk.Frame(t1); f2.pack(anchor="w", padx=14)
        v_sh = tk.StringVar(value=str(self.conf.get("script_host", "")))
        v_su = tk.StringVar(value=str(self.conf.get("script_user", "")))
        v_sp = tk.StringVar(value=str(self.conf.get("script_pass", "")))
        tk.Label(f2, text="Host", font=FS).grid(row=0, column=0, sticky="w")
        tk.Entry(f2, textvariable=v_sh, font=FS, width=20).grid(row=0, column=1, padx=4)
        tk.Label(f2, text="帳號", font=FS).grid(row=1, column=0, sticky="w")
        tk.Entry(f2, textvariable=v_su, font=FS, width=20).grid(row=1, column=1, padx=4)
        tk.Label(f2, text="密碼", font=FS).grid(row=2, column=0, sticky="w")
        tk.Entry(f2, textvariable=v_sp, font=FS, width=20, show="*").grid(row=2, column=1, padx=4)

        v_lt = tk.BooleanVar(value=bool(self.conf.get("do_lt_all", True)))
        tk.Checkbutton(t1, text="預設先執行 LT ALL", font=FS,
                       variable=v_lt).pack(anchor="w", padx=14, pady=(12, 0))

        # ==== 東尼 ====
        t2 = tk.Frame(nb)
        nb.add(t2, text="  東尼  ")

        tk.Label(t2, text="連線方式", font=self.FB).pack(anchor="w", **pad)
        v_t = tk.StringVar(value=self.conf.get("transport", "serial"))
        fr = tk.Frame(t2); fr.pack(anchor="w", padx=14)
        tk.Radiobutton(fr, text="USB 序列埠", font=FS, variable=v_t,
                       value="serial").pack(side="left")
        tk.Radiobutton(fr, text="TCP", font=FS, variable=v_t,
                       value="tcp").pack(side="left", padx=(12, 0))

        tk.Label(t2, text="序列埠（AUTO = 自動選第一個）", font=self.FB).pack(
            anchor="w", pady=(10, 3))
        v_p = tk.StringVar(value=str(self.conf.get("serial_port", "AUTO")))
        cb = ttk.Combobox(t2, textvariable=v_p, font=FS, width=30)
        cb.pack(anchor="w", padx=14)
        ports = list_ports()
        cb["values"] = ["AUTO"] + [d for d, _ in ports]
        if ports:
            tk.Label(t2, text="偵測到：" + "、".join(
                "%s(%s)" % (d, d2[:14]) for d, d2 in ports),
                font=FS, fg="#666", wraplength=460, justify="left").pack(
                anchor="w", padx=14)

        tk.Label(t2, text="TCP 位址 / 埠", font=self.FB).pack(anchor="w", pady=(10, 3))
        f3 = tk.Frame(t2); f3.pack(anchor="w", padx=14)
        v_h = tk.StringVar(value=str(self.conf.get("tcp_host", "")))
        v_pt = tk.StringVar(value=str(self.conf.get("tcp_port", 9000)))
        tk.Entry(f3, textvariable=v_h, font=FS, width=18).pack(side="left")
        tk.Entry(f3, textvariable=v_pt, font=FS, width=7).pack(side="left", padx=6)

        v_ar = tk.BooleanVar(value=bool(self.conf.get("auto_reconnect", True)))
        tk.Checkbutton(t2, text="斷線自動重連", font=FS,
                       variable=v_ar).pack(anchor="w", padx=14, pady=(8, 0))

        # ---- 按鈕 ----
        def do_save():
            self.conf.update({
                "jump_host": v_jh.get().strip(),
                "jump_user": v_ju.get().strip(),
                "jump_pass": v_jp.get(),
                "script_host": v_sh.get().strip(),
                "script_user": v_su.get().strip(),
                "script_pass": v_sp.get(),
                "do_lt_all": bool(v_lt.get()),
                "transport": v_t.get(),
                "serial_port": v_p.get().strip() or "AUTO",
                "tcp_host": v_h.get().strip(),
                "tcp_port": int(v_pt.get()) if v_pt.get().strip().isdigit() else 9000,
                "auto_reconnect": bool(v_ar.get()),
            })
            # ★ 存檔失敗就不要關視窗、不要騙主人「已儲存」
            ok_save, detail = save_conf(self.conf)
            if not ok_save:
                self._log("✗ 設定儲存失敗：%s" % detail, "err")
                messagebox.showerror(
                    "儲存失敗",
                    ("設定沒有寫進去，原因：" + str(detail) + "\n\n"
                     + "常見原因：這個資料夾沒有寫入權限。\n"
                     + "請把程式放到桌面或文件夾，或用管理員身分執行。"))
                return
            self._log("✓ 設定已儲存 → %s" % detail)
            w.destroy()
            if self.connected:
                self.disconnect()
            self.after(300, self.connect)

        rowb = tk.Frame(w)
        rowb.pack(side="bottom", fill="x", padx=12, pady=10)
        tk.Button(rowb, text="儲存", font=F, width=10, command=do_save).pack(side="right")
        tk.Button(rowb, text="取消", font=F, width=8, command=w.destroy).pack(
            side="right", padx=(0, 8))
        tk.Button(rowb, text="測試 AMOS 連線", font=FS,
                  command=self._test_amos).pack(side="left")
        tk.Button(rowb, text="重新偵測序列埠", font=FS,
                  command=lambda: self._refresh(cb)).pack(side="left", padx=6)

    def _test_amos(self):
        cfg = {
            "jump_host": self.conf.get("jump_host"),
            "jump_user": self.conf.get("jump_user"),
            "jump_pass": self.conf.get("jump_pass"),
            "script_host": self.conf.get("script_host"),
            "script_user": self.conf.get("script_user"),
            "script_pass": self.conf.get("script_pass"),
        }
        if not cfg["jump_user"] or not cfg["jump_pass"]:
            messagebox.showinfo("還沒填", "請先填帳號密碼再測試。")
            return
        self._log("── 測試 AMOS 連線 ──", "amos")

        def worker():
            try:
                import amos_client as A
                cl = A.AmosClient(cfg, log=lambda m: self._log_t(m, "amos"))
                cl.test()
                self._log_t("✓ 兩段 SSH 都通了", "rx")
                self.after(0, lambda: messagebox.showinfo("連線成功", "兩段 SSH 都通了。"))
            except Exception as e:
                self._log_t("✗ 連線失敗：%s" % (e,), "err")
                self.after(0, lambda: messagebox.showerror("連線失敗", str(e)[:300]))

        threading.Thread(target=worker, daemon=True).start()

    def _refresh(self, cb):
        ports = list_ports()
        cb["values"] = ["AUTO"] + [d for d, _ in ports]
        self._log("重新偵測：%s" % ("、".join(d for d, _ in ports) or "（無）"))

    def destroy(self):
        try:
            if getattr(self, "execd", None) and self.execd.httpd:
                self.execd.httpd.shutdown()
        except Exception:
            pass
        try:
            if self.link:
                self.link.close()
        except Exception:
            pass
        super().destroy()


def main():
    try:
        App().mainloop()
    except Exception as e:
        print("啟動失敗:", repr(e))
        if "tkinter" in repr(e).lower():
            print("這台電腦的 Python 沒有 tkinter，請安裝官方完整版。")
        sys.exit(1)


if __name__ == "__main__":
    main()
