@echo off
chcp 65001 >nul
title 安裝 CP210x 驅動（小輪子用）
cd /d "%~dp0"

echo ============================================
echo   安裝 Silicon Labs CP210x 驅動
echo ============================================
echo.
echo 這是小輪子的 USB 晶片驅動。
echo 沒裝這個，電腦就看不到小輪子的 COM 埠。
echo.
echo ※ 需要「系統管理員」權限。
echo   如果等一下出現 UAC 視窗，請按「是」。
echo.
pause

net session >nul 2>&1
if errorlevel 1 (
    echo [提示] 目前不是管理員，改用提權方式重跑...
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

echo.
echo [1/3] 安裝驅動（靜默）...
pnputil /add-driver "%~dp0silabser.inf" /install
if errorlevel 1 (
    echo.
    echo [失敗] pnputil 回報錯誤。
    echo 改用替代方式：手動指定驅動
    echo.
    echo 請照這樣做：
    echo   1. 插上小輪子
    echo   2. 開始 -^> 裝置管理員
    echo   3. 找有「!」的裝置 -^> 右鍵 -^> 更新驅動程式
    echo   4. 瀏覽電腦 -^> 選這個資料夾：%~dp0
    echo.
    pause
    exit /b 1
)

echo.
echo [2/3] 重新掃描硬體...
pnputil /scan-devices >nul 2>&1

echo.
echo [3/3] 檢查 COM 埠...
powershell -NoProfile -Command "Start-Sleep -Seconds 2; Get-PnpDevice -PresentOnly -Class Ports -ErrorAction SilentlyContinue | Select-Object Status,FriendlyName | Format-Table -AutoSize"

echo.
echo ============================================
echo   完成。請確認上面有沒有出現 CP210x 的 COM 埠。
echo ============================================
echo.
echo 有出現：可以關掉這個視窗，然後雙擊「小輪子執行端.exe」
echo 沒出現：把這個視窗截圖給珠珢看
echo.
pause
